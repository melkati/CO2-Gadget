var captivePortalDebug=false;var forcedCaptivePortalDebug=false;var captivePortalActive=false;var forcedCaptivePortal=false;var captivePortalNoTimeout=false;var forcedCaptivePortalNoTimeout=false;var relaxedSecurity=false;var forcedRelaxedSecurity=false;var forceCaptivePortalActive=false;var preferencesDebug=false;var captivePortalStatus={captivePortalTimeLeft:0};var previousData={forceCaptivePortalActive:false,captivePortalActive:false,forcedCaptivePortal:false,captivePortalDebug:false,relaxedSecurity:false,forcedCaptivePortalDebug:false,captivePortalNoTimeout:false};var features={SUPPORT_BLE:false,SUPPORT_BTHOME_BLE:false,SUPPORT_BUZZER:false,SUPPORT_ESPNOW:false,SUPPORT_MDNS:false,SUPPORT_MQTT:false,SUPPORT_MQTT_DISCOVERY:false,SUPPORT_OTA:false,SUPPORT_LOW_POWER:false,SUPPORT_CIRCULAR_BUFFER:false};var featuresLoaded=false;function fetchWithTimeout(url,options,timeoutMs){if(timeoutMs===undefined)timeoutMs=6000;const controller=new AbortController();const timeoutId=setTimeout(()=>controller.abort(),timeoutMs);const fetchOptions=Object.assign({},options||{},{signal:controller.signal});return fetch(url,fetchOptions).then(function(response){clearTimeout(timeoutId);return response;}).catch(function(error){clearTimeout(timeoutId);throw error;});}
function restartESP32(){const isConfirmed=confirm("Are you sure you want to restart the ESP32?");if(isConfirmed){if(preferencesDebug)console.log("Restarting ESP32...");fetchWithTimeout('/restart',{method:'GET',headers:{'Content-Type':'text/plain'}},5000).then(response=>{if(response.ok){console.log('ESP32 restart initiated');}else{throw new Error(`HTTP error! Status: ${response.status}`);}}).catch(error=>console.error('Error restarting ESP32:',error));}}
function highlightCurrentPage(){const currentPage=window.location.pathname.split("/").pop();const navLinks=document.querySelectorAll(".navbar .nav-content a");navLinks.forEach(link=>{if(link.getAttribute("href")===currentPage){link.classList.add("active");}});}
function loadFeaturesFromServer(){fetchWithTimeout('/getFeaturesAsJson',{},8000).then(response=>response.json()).then(data=>{console.log('Fetching loadFeaturesFromServer successful!');handleFeaturesData(data);}).catch(error=>console.error('Error fetching features:',error));}
function readBatteryVoltage(){return fetchWithTimeout('/readBatteryVoltage',{},5000).then(response=>{if(!response.ok)throw new Error('Network response was not ok.');return response.text();}).catch(error=>{console.error('Error fetching battery voltage:',error);throw error;});}
function readCO2Data(){return fetchWithTimeout('/readCO2',{},5000).then(response=>{if(!response.ok)throw new Error('Network response was not ok.');return response.text();}).then(data=>parseFloat(data)).catch(error=>{console.error("Error fetching CO2 data:",error);throw error;});}
function readTemperatureData(){return fetchWithTimeout('/readTemperature',{},5000).then(response=>{if(!response.ok)throw new Error('Network response was not ok.');return response.text();}).then(data=>parseFloat(data).toFixed(1)).catch(error=>{console.error("Error fetching temperature data:",error);throw error;});}
function readHumidityData(){return fetchWithTimeout('/readHumidity',{},5000).then(response=>{if(!response.ok)throw new Error('Network response was not ok.');return response.text();}).then(data=>parseFloat(data).toFixed(0)).catch(error=>{console.error("Error fetching humidity data:",error);throw error;});}
function readMeasurementInterval(){return fetchWithTimeout('/getMeasurementInterval',{},5000).then(response=>{if(!response.ok)throw new Error('Network response was not ok.');return response.text();}).then(data=>parseInt(data)*1000).catch(error=>{console.error("Error fetching measurement interval:",error);throw error;});}
function readFreeHeap(){return fetchWithTimeout('/getFreeHeap',{},5000).then(response=>{if(!response.ok)throw new Error('Network response was not ok.');return response.text();}).catch(error=>{console.error('Error fetching free heap:',error);throw error;});}
function readMinFreeHeap(){return fetchWithTimeout('/getMinFreeHeap',{},5000).then(response=>{if(!response.ok)throw new Error('Network response was not ok.');return response.text();}).catch(error=>{console.error('Error fetching min free heap:',error);throw error;});}
function handleFeaturesData(data){features.SUPPORT_BLE=data.BLE!==undefined?data.BLE:false;features.SUPPORT_BTHOME_BLE=data.BTHomeBLE!==undefined?data.BTHomeBLE:false;features.SUPPORT_BUZZER=data.Buzzer!==undefined?data.Buzzer:false;features.SUPPORT_ESPNOW=data.EspNow!==undefined?data.EspNow:false;features.SUPPORT_MDNS=data.mDNS!==undefined?data.mDNS:false;features.SUPPORT_MQTT=data.MQTT!==undefined?data.MQTT:false;features.SUPPORT_MQTT_DISCOVERY=data.MQTTDiscovery!==undefined?data.MQTTDiscovery:false;features.SUPPORT_OTA=data.OTA!==undefined?data.OTA:false;features.SUPPORT_LOW_POWER=data.LowPower!==undefined?data.LowPower:false;features.SUPPORT_CIRCULAR_BUFFER=data.CircularBuffer!==undefined?data.CircularBuffer:false;featuresLoaded=true;if(captivePortalDebug)console.log('Mapped Features:',features);}
function getFeaturesAsJson(retries){if(retries===undefined)retries=3;return fetchWithTimeout('/getFeaturesAsJson',{},8000).then(response=>{if(!response.ok){console.error('Response not OK:',response.status,response.statusText);throw new Error('Network response was not ok '+response.statusText);}
return response.json();}).then(data=>{console.log("Received JSON:",data);handleFeaturesData(data);}).catch(error=>{if(retries>0){const delay=1000*Math.pow(2,3-retries);console.warn(`CO2 Gadget features fetch failed, retrying in ${delay}ms... (${retries} left)`,error);return new Promise(resolve=>setTimeout(resolve,delay)).then(()=>getFeaturesAsJson(retries-1));}
console.error("Error fetching CO2 Gadget features, leaving WebUI settings visible:",error);});}
function setFormGroupVisibility(elementId,isVisible){const element=document.getElementById(elementId);const formGroup=element?element.closest(".form-group"):null;if(formGroup)formGroup.classList.toggle("hidden",!isVisible);if(element&&!isVisible&&element.type==="checkbox"){element.checked=false;element.disabled=true;}else if(element){element.disabled=false;}}
function fetchVersion(){return fetchWithTimeout('/getVersion',{},8000).then(response=>{if(!response.ok)throw new Error('Network response was not ok.');return response.json();}).then(data=>{if(captivePortalDebug)console.log('Version information:',data);return data;}).catch(error=>{console.error('Error fetching version:',error);throw error;});}
function getVersionStr(){return fetchVersion().then(versionInfo=>{let versionText=`v${versionInfo.firmVerMajor}.${versionInfo.firmVerMinor}.${versionInfo.firmRevision}`;if(versionInfo.firmBranch){versionText+=`-${versionInfo.firmBranch}`;}
versionText+=` (Flavour: ${versionInfo.firmFlavour})`;if(versionInfo.firmBuildDate)versionText+=` \u2014 Built: ${versionInfo.firmBuildDate}`;if(versionInfo.firmBuildTime)versionText+=` at ${versionInfo.firmBuildTime}`;if(captivePortalDebug)console.log('Version string:',versionText);return versionText;}).catch(error=>{console.error('Error getting version as string:',error);throw error;});}
function readPreferencesFromServer(){return fetchWithTimeout('/getActualSettingsAsJson',{},8000).then(response=>{if(!response.ok)throw new Error('Network response was not ok.');return response.json();}).catch(error=>{console.error('Error fetching preferences:',error);throw error;});}
function initNavBar(){if(captivePortalDebug)
console.log("Document loaded. Initializing navbar...");if(features.SUPPORT_OTA){const otaBadge=document.getElementById("otaBadge");if(otaBadge)otaBadge.classList.remove("hidden");const maintenanceSection=document.getElementById("maintenanceSection");if(maintenanceSection)maintenanceSection.classList.remove("hidden");}
if(features.SUPPORT_CIRCULAR_BUFFER){const chartsLink=document.getElementById("chartsLink");if(chartsLink){chartsLink.classList.remove("hidden");}else{console.error('Element with ID "chartsLink" not found.')}}
const lowPowerIcon=document.getElementById("lightingIcon");if(lowPowerIcon&&featuresLoaded)lowPowerIcon.classList.toggle("hidden",!features.SUPPORT_LOW_POWER);}
function goLowPower(){if(featuresLoaded&&!features.SUPPORT_LOW_POWER){console.warn('Low power support is not compiled into this firmware.');return;}
console.log('Low power mode activated');fetchWithTimeout('/goLowPower',{method:'GET',headers:{'Content-Type':'text/plain'}},5000).then(response=>{if(response.ok){console.log('Low power mode activated');}else{throw new Error(`HTTP error! Status: ${response.status}`);}}).catch(error=>console.error('Error activating low power mode:',error));}
document.addEventListener("DOMContentLoaded",function(){getFeaturesAsJson().then(initNavBar);readPreferencesFromServer().then(data=>{if(data&&data.hostName)document.title+=` (${data.hostName})`;}).catch(error=>console.warn('Could not get hostName for title:',error));const lightingIcon=document.getElementById('lightingIcon');if(lightingIcon)lightingIcon.addEventListener('click',goLowPower);initFullscreen();});const _fsExpandPath="M32 32C14.3 32 0 46.3 0 64v96c0 17.7 14.3 32 32 32s32-14.3 32-32V96h64c17.7 0 32-14.3 32-32s-14.3-32-32-32H32zM64 352c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7 14.3 32 32 32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H64V352zM320 32c-17.7 0-32 14.3-32 32s14.3 32 32 32h64v64c0 17.7 14.3 32 32 32s32-14.3 32-32V64c0-17.7-14.3-32-32-32H320zM448 352c0-17.7-14.3-32-32-32s-32 14.3-32 32v64H320c-17.7 0-32 14.3-32 32s14.3 32 32 32h96c17.7 0 32-14.3 32-32V352z";const _fsCompressPath="M160 64c0-17.7-14.3-32-32-32s-32 14.3-32 32v64H32c-17.7 0-32 14.3-32 32s14.3 32 32 32h96c17.7 0 32-14.3 32-32V64zM32 320c-17.7 0-32 14.3-32 32s14.3 32 32 32H96v64c0 17.7 14.3 32 32 32s32-14.3 32-32V352c0-17.7-14.3-32-32-32H32zM352 64c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7 14.3 32 32 32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H352V64zM320 320c-17.7 0-32 14.3-32 32v96c0 17.7 14.3 32 32 32s32-14.3 32-32V352h64c17.7 0 32-14.3 32-32s-14.3-32-32-32H320z";function initFullscreen(){const btn=document.getElementById('iconFullscreen');if(!btn)return;const fspath=document.getElementById('fullscreenPath');const fsicon=document.getElementById('fullscreenIcon');const navbar=document.getElementById('navbar');let hideTimer=null;function updateFsIcon(isFs){if(!fspath||!fsicon)return;fsicon.setAttribute('viewBox','0 0 448 512');fspath.setAttribute('d',isFs?_fsCompressPath:_fsExpandPath);}
function showNavbar(){if(!navbar)return;navbar.classList.add('fs-nav-visible');clearTimeout(hideTimer);hideTimer=setTimeout(()=>navbar.classList.remove('fs-nav-visible'),2500);}
btn.addEventListener('click',()=>{if(!document.fullscreenElement){document.documentElement.requestFullscreen().catch(()=>{});}else{document.exitFullscreen().catch(()=>{});}});document.addEventListener('fullscreenchange',()=>{const isFs=!!document.fullscreenElement;updateFsIcon(isFs);document.body.classList.toggle('is-fullscreen',isFs);if(isFs){showNavbar();document.addEventListener('mousemove',showNavbar);}else{clearTimeout(hideTimer);if(navbar)navbar.classList.remove('fs-nav-visible');document.removeEventListener('mousemove',showNavbar);}});}
function getTzOffsetHours(){const stored=localStorage.getItem('co2gadget_tz');if(stored!==null&&stored!=='')return parseFloat(stored);return-new Date().getTimezoneOffset()/60;}
function getTzOffsetMs(){return getTzOffsetHours()*3600000;}
function saveTzOffset(offsetHours){localStorage.setItem('co2gadget_tz',String(offsetHours));document.dispatchEvent(new CustomEvent('tzChange',{detail:{offset:parseFloat(offsetHours)}}));}
function formatTimeInTz(utcMs){const pad=n=>String(n).padStart(2,'0');const d=new Date(utcMs+getTzOffsetMs());return pad(d.getUTCHours())+':'+pad(d.getUTCMinutes())+':'+pad(d.getUTCSeconds());}
function formatDatetimeLocalInTz(utcMs){const pad=n=>String(n).padStart(2,'0');const d=new Date(utcMs+getTzOffsetMs());return d.getUTCFullYear()+'-'+pad(d.getUTCMonth()+1)+'-'+pad(d.getUTCDate())+'T'+pad(d.getUTCHours())+':'+pad(d.getUTCMinutes());}
function tzOffsetLabel(offsetHours){const sign=offsetHours>=0?'+':'−';const abs=Math.abs(offsetHours);const h=Math.floor(abs);const m=Math.round((abs-h)*60);return'UTC'+sign+String(h)+(m?':'+String(m).padStart(2,'0'):'');}
const lightThemeIconPath=`M375.7 19.7c-1.5-8-6.9-14.7-14.4-17.8s-16.1-2.2-22.8 2.4L256 61.1 173.5 4.2c-6.7-4.6-15.3-5.5-22.8-2.4s-12.9 9.8-14.4 17.8l-18.1 98.5L19.7 136.3c-8 1.5-14.7 6.9-17.8 14.4s-2.2 16.1 2.4 22.8L61.1 256 4.2 338.5c-4.6 6.7-5.5 15.3-2.4 22.8s9.8 13 17.8 14.4l98.5 18.1 18.1 98.5c1.5 8 6.9 14.7 14.4 17.8s16.1 2.2 22.8-2.4L256 450.9l82.5 56.9c6.7 4.6 15.3 5.5 22.8 2.4s12.9-9.8 14.4-17.8l18.1-98.5 98.5-18.1c8-1.5 14.7-6.9 17.8-14.4s2.2-16.1-2.4-22.8L450.9 256l56.9-82.5c4.6-6.7 5.5-15.3 2.4-22.8s-9.8-12.9-17.8-14.4l-98.5-18.1L375.7 19.7zM269.6 110l65.6-45.2 14.4 78.3c1.8 9.8 9.5 17.5 19.3 19.3l78.3 14.4L402 242.4c-5.7 8.2-5.7 19 0 27.2l45.2 65.6-78.3 14.4c-9.8 1.8-17.5 9.5-19.3 19.3l-14.4 78.3L269.6 402c-8.2-5.7-19-5.7-27.2 0l-65.6 45.2-14.4-78.3c-1.8-9.8-9.5-17.5-19.3-19.3L64.8 335.2 110 269.6c5.7-8.2 5.7-19 0-27.2L64.8 176.8l78.3-14.4c9.8-1.8 17.5-9.5 19.3-19.3l14.4-78.3L242.4 110c8.2 5.7 19 5.7 27.2 0zM256 368a112 112 0 1 0 0-224 112 112 0 1 0 0 224zM192 256a64 64 0 1 1 128 0 64 64 0 1 1 -128 0z`;const darkThemeIconPath=`M144.7 98.7c-21 34.1-33.1 74.3-33.1 117.3c0 98 62.8 181.4 150.4 211.7c-12.4 2.8-25.3 4.3-38.6 4.3C126.6 432 48 353.3 48 256c0-68.9 39.4-128.4 96.8-157.3zm62.1-66C91.1 41.2 0 137.9 0 256C0 379.7 100 480 223.5 480c47.8 0 92-15 128.4-40.6c1.9-1.3 3.7-2.7 5.5-4c4.8-3.6 9.4-7.4 13.9-11.4c2.7-2.4 5.3-4.8 7.9-7.3c5-4.9 6.3-12.5 3.1-18.7s-10.1-9.7-17-8.5c-3.7 .6-7.4 1.2-11.1 1.6c-5 .5-10.1 .9-15.3 1c-1.2 0-2.5 0-3.7 0c-.1 0-.2 0-.3 0c-96.8-.2-175.2-78.9-175.2-176c0-54.8 24.9-103.7 64.1-136c1-.9 2.1-1.7 3.2-2.6c4-3.2 8.2-6.2 12.5-9c3.1-2 6.3-4 9.6-5.8c6.1-3.5 9.2-10.5 7.7-17.3s-7.3-11.9-14.3-12.5c-3.6-.3-7.1-.5-10.7-.6c-2.7-.1-5.5-.1-8.2-.1c-3.3 0-6.5 .1-9.8 .2c-2.3 .1-4.6 .2-6.9 .4z`;const lightLowPowerIconPath=`M0 256L28.5 28c2-16 15.6-28 31.8-28H228.9c15 0 27.1 12.1 27.1 27.1c0 3.2-.6 6.5-1.7 9.5L208 160H347.3c20.2 0 36.7 16.4 36.7 36.7c0 7.4-2.2 14.6-6.4 20.7l-192.2 281c-5.9 8.6-15.6 13.7-25.9 13.7h-2.9c-15.7 0-28.5-12.8-28.5-28.5c0-2.3 .3-4.6 .9-6.9L176 288H32c-17.7 0-32-14.3-32-32z`;const darkLowPowerIconPath=`M0 256L28.5 28c2-16 15.6-28 31.8-28H228.9c15 0 27.1 12.1 27.1 27.1c0 3.2-.6 6.5-1.7 9.5L208 160H347.3c20.2 0 36.7 16.4 36.7 36.7c0 7.4-2.2 14.6-6.4 20.7l-192.2 281c-5.9 8.6-15.6 13.7-25.9 13.7h-2.9c-15.7 0-28.5-12.8-28.5-28.5c0-2.3 .3-4.6 .9-6.9L176 288H32c-17.7 0-32-14.3-32-32z`;function setThemeIcon(theme){const iconPath=document.getElementById("iconPath");const themeIcon=document.getElementById("themeIcon");if(theme==="dark"){themeIcon.setAttribute("viewBox","0 0 384 512");iconPath.setAttribute("d",darkThemeIconPath);}else{themeIcon.setAttribute("viewBox","0 0 512 512");iconPath.setAttribute("d",lightThemeIconPath);}}
function setLowPowerIcon(theme){const iconPathLowPower=document.getElementById("iconPathLowPower");const lowPowerIcon=document.getElementById("lightingIcon");if(!lowPowerIcon||!iconPathLowPower)return;if(theme==="dark"){lowPowerIcon.setAttribute("viewBox","0 0 384 512");iconPathLowPower.setAttribute("d",darkLowPowerIconPath);}else{lowPowerIcon.setAttribute("viewBox","0 0 384 512");iconPathLowPower.setAttribute("d",lightLowPowerIconPath);}}
function toggleTheme(){const htmlElement=document.documentElement;const currentTheme=htmlElement.getAttribute("theme");const newTheme=currentTheme==="dark"?"light":"dark";console.debug("Toggle theme function called");console.debug("Current theme:",currentTheme);console.debug("New theme:",newTheme);htmlElement.setAttribute("theme",newTheme);console.debug("Theme set to:",newTheme);localStorage.setItem("theme",newTheme);setThemeIcon(newTheme);setLowPowerIcon(newTheme);}
function initializeTheme(){const savedTheme=localStorage.getItem("theme");if(savedTheme){document.documentElement.setAttribute("theme",savedTheme);setThemeIcon(savedTheme);setLowPowerIcon(savedTheme);}else{setThemeIcon('light');setLowPowerIcon('light');}}
function initializeThemeSwitch(){const colorSwitch=document.querySelector("#iconBulb");if(colorSwitch){colorSwitch.addEventListener("click",toggleTheme);}else{console.error('Element with ID "iconBulb" not found.');}}
document.addEventListener("DOMContentLoaded",function(){initializeTheme();initializeThemeSwitch();const _li=document.getElementById('lightingIcon');if(_li)_li.addEventListener('click',goLowPower);});function setCaptivePortalSettings(timeToWait,isInitialSetup=false){fetchWithTimeout('/setCaptivePortalSettings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({timeToWaitForCaptivePortal:timeToWait,captivePortalActive,captivePortalNoTimeout,forcedCaptivePortal,captivePortalDebug,relaxedSecurity:relaxedSecurity?true:undefined})},5000).then(response=>{if(!response.ok){throw new Error('Network response was not ok');}
if(captivePortalDebug){console.log('Captive Portal settings updated on server successfully:',{forcedCaptivePortal,captivePortalActive,captivePortalNoTimeout,timeToWaitForCaptivePortal:timeToWait,captivePortalDebug,relaxedSecurity});}}).catch(error=>console.error('Error setting captive portal settings:',error));}
function storeCaptivePortalStatus(data){captivePortalStatus.captivePortalTimeLeft=data.captivePortalTimeLeft;}
function handleCaptivePortalData(data){try{storeCaptivePortalStatus(data);const changes=checkForPropertyChanges(data);logPropertyChanges(changes);updateDebugMode(data);updateActiveStates(data);if(debugWindowActive){updateDebugWindow(data);}}catch(error){console.error('Error in handleCaptivePortalData function:',error);throw error;}}
function checkForPropertyChanges(data){const changes={};const propertiesToCheck=['forceCaptivePortalActive','captivePortalActive','forcedCaptivePortal','captivePortalDebug','relaxedSecurity','forcedCaptivePortalDebug','captivePortalNoTimeout'];propertiesToCheck.forEach(key=>{if(data[key]!==previousData[key]){changes[key]={previous:previousData[key],current:data[key]};previousData[key]=data[key];}});return changes;}
function logPropertyChanges(changes){if(Object.keys(changes).length>0){console.log('Detected changes in captive portal data:',changes);}}
function updateDebugMode(data){if(data.captivePortalDebug!==undefined){if(data.captivePortalDebug!==captivePortalDebug){captivePortalDebug=data.captivePortalDebug;console.log('Captive portal debug mode set to:',captivePortalDebug);}}}
function updateActiveStates(data){forcedCaptivePortal=data.forceCaptivePortalActive||false;captivePortalActive=(data.captivePortalActive||false)||forcedCaptivePortal;}
function getCaptivePortalSettings(){fetchWithTimeout('/getCaptivePortalStatusAsJson',{},5000).then(response=>{if(!response.ok){console.error('Response not OK:',response.status,response.statusText);throw new Error('Network response was not ok '+response.statusText);}
return response.json();}).then(captivePortalSettings=>{try{handleCaptivePortalData(captivePortalSettings);}catch(e){console.error("Error in handleCaptivePortalData:",e);throw e;}}).catch(error=>{console.error("Error fetching captive portal status:",error);});}
function setupInitialSettings(){if(window.location.href.includes("forcedCaptivePortal")){if(captivePortalDebug)console.log('Forcing captive portal to be active in test mode by forcedCaptivePortal parameter in URL');forcedCaptivePortal=true;captivePortalActive=true;}
if(window.location.href.includes("debugCaptivePortal")){forcedCaptivePortalDebug=true;captivePortalDebug=true;console.log('Forcing captive portal debug mode to be active by debugCaptivePortal parameter in URL');}
setCaptivePortalSettings(60,true);}
function initializeCaptivePortal(){if(captivePortalDebug)console.log('Document loaded. Initializing captive portal for preferences.html');getFeaturesAsJson();if(features.SUPPORT_OTA){const otaBadge=document.getElementById('otaBadge');if(otaBadge)otaBadge.classList.remove('hidden');const maintenanceSection=document.getElementById('maintenanceSection');if(maintenanceSection)maintenanceSection.classList.remove('hidden');}
setupInitialSettings();setInterval(getCaptivePortalSettings,5000);}
function showCaptivePortalSettings(show){const captivePortalSettings=document.getElementById('captivePortalSettings');if(captivePortalSettings){if(show){captivePortalSettings.classList.remove('hidden');}else{captivePortalSettings.classList.add('hidden');}}else{console.error('Element with ID "captivePortalSettings" not found.');}}
function adjustContentPadding(){const navbar=document.querySelector('.navbar');const content=document.querySelector('.content');if(navbar&&content){const navbarHeight=navbar.offsetHeight;content.style.paddingTop=`${navbarHeight}px`;}}
document.addEventListener("DOMContentLoaded",function(){const currentPage=window.location.pathname.split("/").pop();adjustContentPadding();if(currentPage==="preferences.html"){initializeCaptivePortal();highlightCurrentPage();const debugWindow=document.getElementById('debug-window');if(captivePortalDebug||debugWindowActive){if(debugWindow){createDebugWindow(debugWindow);debugWindowActive=true;debugWindow.style.display='block';}else{console.error('Element with ID "debug-window" not found.');}}else{if(debugWindow){debugWindow.style.display='none';debugWindowActive=false;}}}else{if(captivePortalDebug)console.log('Not on preferences.html, skipping debug window initialization');}});var captivePortalStatusBarActive=false;var forcedCaptivePortalStatusBar=false;var captivePortalStatusBarDebug=true;function updateStatusBarContent(){if(captivePortalActive){const statusBarContentElement=document.getElementById('status-bar-content');if(statusBarContentElement){if(!captivePortalNoTimeout){statusBarContentElement.innerHTML=`
                <span>Timeout: <strong>${captivePortalStatus.captivePortalTimeLeft}</strong> seconds</span>
                <label><input type="checkbox" id="disableTimeoutCheckbox"> Disable</label>
            `;}else{statusBarContentElement.innerHTML=`
                <span>Timeout: <strong>Disabled</strong></span>
                <label><input type="checkbox" id="disableTimeoutCheckbox" checked> Disable</label>
            `;}}else{console.error('Element with ID "status-bar-content" not found.');}
const disableTimeoutCheckbox=document.getElementById('disableTimeoutCheckbox');if(disableTimeoutCheckbox){disableTimeoutCheckbox.checked=captivePortalNoTimeout;disableTimeoutCheckbox.addEventListener('change',function(){const timeToWait=this.checked?0:60;captivePortalNoTimeout=this.checked;console.log('Setting time to wait:',timeToWait);console.log('Disabling timeout:',captivePortalNoTimeout);setCaptivePortalSettings(timeToWait);});}}else{updateStatusBar('Captive portal inactive');showCaptivePortalStatusBar(false);}}
function showCaptivePortalStatusBar(show){if(captivePortalStatusBarActive===show)return;const captivePortalStatusBar=document.getElementById('captive-portal-status-bar');if(captivePortalStatusBar){if(captivePortalStatusBarDebug)console.log('Captive portal status bar found:',captivePortalStatusBar);if(show){if(captivePortalStatusBarDebug)console.log('Showing captive portal status bar');captivePortalStatusBar.classList.remove('hidden-captive-portal-status-bar');}else{if(captivePortalStatusBarDebug)console.log('Hiding captive portal status bar');captivePortalStatusBar.classList.add('hidden-captive-portal-status-bar');}
captivePortalStatusBarActive=show;}else{console.error('Element with ID "captive-portal-status-bar" not found.');}}
function initializeCaptivePortalStatusBar(){if(captivePortalStatusBarDebug)console.log('Initializing captive portal status bar');const captivePortalStatusBar=document.getElementById('captive-portal-status-bar');if(captivePortalStatusBar){if(captivePortalStatusBarDebug)console.log('Injecting captive portal status bar content');captivePortalStatusBar.innerHTML=`
            <span id="status-bar-content"></span>
            <span id="hide-captive-portal-status-bar-button" onclick="showCaptivePortalStatusBar(false)">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="10" stroke="black" stroke-width="2"/>
                    <line x1="8" y1="8" x2="16" y2="16" stroke="black" stroke-width="2"/>
                    <line x1="16" y1="8" x2="8" y2="16" stroke="black" stroke-width="2"/>
                </svg>
            </span>
        `;if(forcedCaptivePortal)showCaptivePortalStatusBar(true);}else{console.error('Element with ID "captive-portal-status-bar" not found.');}}
function initializeCaptivePortalStatusBarUrlParameters(){captivePortalStatusBarDebug=window.location.href.includes("captivePortalStatusBarDebug");if(captivePortalStatusBarDebug)console.log('Captive portal status bar debug:',captivePortalStatusBarDebug);forcedCaptivePortalStatusBar=window.location.href.includes("forcedCaptivePortalStatusBar");if(captivePortalStatusBarDebug)console.log('Captive portal status bar forced:',forcedCaptivePortalStatusBar);}
function updateStatusBar(content){if(!captivePortalStatusBarActive)return;if(captivePortalStatusBarDebug)console.log('Updating status bar');const statusContent=document.getElementById('status-bar-content');if(statusContent){statusContent.textContent=content;if(captivePortalStatusBarDebug)console.log('Updating status bar content:',content);}else{console.error('Element with ID "status-bar-content" not found.');}}
document.addEventListener("DOMContentLoaded",function(){initializeCaptivePortalStatusBarUrlParameters();initializeCaptivePortalStatusBar();setInterval(updateStatusBarContent,1000);});var canPingServer=true;let previousServerStatusDotState={show:null,colorClass:'',title:''};function displayServerStatusDot(show,colorClass='status-dot-cyan',title=''){const serverStatusDot=document.getElementById('server-status-dot');if(serverStatusDot){const hasStateChanged=previousServerStatusDotState.show!==show||previousServerStatusDotState.colorClass!==colorClass||previousServerStatusDotState.title!==title;if(hasStateChanged){serverStatusDot.className='status-dot';serverStatusDot.classList.add(show?colorClass:'status-dot-hidden');serverStatusDot.title=title;if(captivePortalDebug){console.log(`Server status dot updated: show=${show}, colorClass=${colorClass}, title=${title}`);}
previousServerStatusDotState.show=show;previousServerStatusDotState.colorClass=colorClass;previousServerStatusDotState.title=title;}}else{console.error('Element with ID "server-status-dot" not found.');}}
function checkServerConnection(){fetchWithTimeout('/pingServer',{},3000).then(response=>{canPingServer=response.ok;if(!response.ok)captivePortalActive=false;}).catch(error=>{console.error('Error pinging server:',error);canPingServer=false;captivePortalActive=false;});}
function updateServerStatusDot(){let show,colorClass,title;if(!canPingServer){show=true;colorClass='status-dot-red';title='Connection to server lost';}else if(!captivePortalActive){show=false;colorClass='status-dot-hidden';title='Captive portal inactive';}else if(forcedCaptivePortal){show=true;colorClass='status-dot-blue';title='Captive portal active (test mode)';}else{show=true;colorClass='status-dot-cyan';title='Captive portal active';}
displayServerStatusDot(show,colorClass,title);}
document.addEventListener("DOMContentLoaded",function(){setInterval(updateServerStatusDot,5000);setInterval(checkServerConnection,5000);});var captivePortalDebug=false;var forcedCaptivePortalDebug=false;var debugWindowActive=false;function updateDebugWindow(data){if(debugWindowActive){const debugContent=document.getElementById('debug-content');if(debugContent){let content=`
            <div>captivePortalActive: ${captivePortalActive}</div>
            <div>captivePortalNoTimeout: ${captivePortalNoTimeout}</div>
            <div>timeToWaitForCaptivePortal: ${data.timeToWaitForCaptivePortal}</div>`;if(captivePortalActive&&!captivePortalNoTimeout){content+=`<div>captivePortalTimeLeft: ${captivePortalStatus.captivePortalTimeLeft}</div> `;}else{if(captivePortalNoTimeout){content+=`<div>Timeout: <strong>Disabled</strong></div>`;}}
if(relaxedSecurity){content+=`<div>relaxedSecurity: ${relaxedSecurity}</div>`;}
if(forcedCaptivePortal){content+=`<div>forcedCaptivePortal: ${forcedCaptivePortal}</div>`;}
if(forcedCaptivePortalDebug){content+=`<div>forcedCaptivePortalDebug: ${forcedCaptivePortalDebug}</div>`;}
debugContent.innerHTML=content;showDebugWindow(true);}}else{showDebugWindow(false);}}
function showDebugWindow(show){const debugWindow=document.getElementById('debug-window');if(debugWindow){const isCurrentlyVisible=!debugWindow.classList.contains('hidden-debug-window')&&debugWindow.style.display!=='none';if(show&&!isCurrentlyVisible){debugWindow.classList.remove('hidden-debug-window');debugWindow.style.display='block';debugWindowActive=true;if(captivePortalDebug)console.log('Showing debug window');}else if(!show&&isCurrentlyVisible){debugWindow.classList.add('hidden-debug-window');debugWindow.style.display='none';debugWindowActive=false;if(captivePortalDebug)console.log('Hiding debug window');}}else{console.error('Element with ID "debug-window" not found.');}
showCaptivePortalSettings(show);}
function createDebugWindow(){const debugWindow=document.getElementById('debug-window');const closeButton=document.createElement('button');closeButton.id='close-debug-window';closeButton.innerHTML='[X]';closeButton.onclick=()=>{showDebugWindow(false);};debugWindow.appendChild(closeButton);const debugContent=document.createElement('div');debugContent.id='debug-content';debugWindow.appendChild(debugContent);}
function initializeDebugWindowUrlParameters(){if(window.location.href.includes("forcedDebugWindow")){if(captivePortalDebug){console.log('Forcing debug window to be active by forcedDebugWindow parameter in URL');forcedCaptivePortalDebug=true;debugWindowActive=true;}}}
document.addEventListener("DOMContentLoaded",function(){var currentFileName=window.location.pathname.split("/").pop();if(currentFileName==="preferences.html"){initializeDebugWindowUrlParameters();createDebugWindow();}});function tsToDatetimeLocal(ts){const d=new Date(ts);const pad=n=>String(n).padStart(2,'0');return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+'T'+pad(d.getHours())+':'+pad(d.getMinutes());}
function downloadText(filename,content){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([content],{type:'text/plain'}));a.download=filename;a.click();URL.revokeObjectURL(a.href);}
function buildPoints(data){const values=data.data;const interval=data.intervalDuration;const end=data.end;const newestTs=Date.now();return values.map((v,i)=>[newestTs+(i-end)*interval,v]);}
function filterPoints(points,fromTs,toTs){return points.filter(([ts])=>ts>=fromTs&&ts<=toTs);}
function injectControls(){const container=document.getElementById('container');if(!container||document.getElementById('charts-controls'))return;const panel=document.createElement('div');panel.id='charts-controls';panel.innerHTML=`
        <div class="charts-filter-group">
            <label class="charts-filter-toggle" title="Activar filtro de rango de fechas">
                <input type="checkbox" id="charts-filter-enabled">
                <span>Rango de fechas:</span>
            </label>
            <div id="charts-range-inputs" class="charts-range-inputs charts-range-disabled">
                <input type="datetime-local" id="charts-from" title="Desde">
                <span class="charts-range-sep">→</span>
                <input type="datetime-local" id="charts-to" title="Hasta">
                <button id="charts-apply" class="btn-charts">Aplicar</button>
            </div>
        </div>
        <div class="charts-export-btns">
            <span class="charts-export-label">Exportar:</span>
            <button id="charts-csv"  class="btn-charts" title="Descargar datos en CSV">CSV</button>
            <button id="charts-json" class="btn-charts" title="Descargar datos en JSON">JSON</button>
            <button id="charts-png"  class="btn-charts" title="Descargar gráfico como imagen PNG">PNG</button>
            <button id="charts-svg"  class="btn-charts" title="Descargar gráfico como vector SVG">SVG</button>
        </div>
    `;const style=document.createElement('style');style.textContent=`
        #charts-controls {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 8px 16px;
            margin-bottom: 14px;
            padding: 10px 16px;
            border-radius: var(--r-md, 10px);
            background: var(--surface-2, #f5f5f7);
            border: 1px solid var(--border, #d1d1d6);
            font-size: .85rem;
        }
        /* Filter group: checkbox + date pickers always visually together */
        .charts-filter-group {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            flex: 1;
            min-width: 0;
        }
        .charts-filter-toggle {
            display: flex;
            align-items: center;
            gap: 7px;
            cursor: pointer;
            user-select: none;
            white-space: nowrap;
        }
        .charts-filter-toggle input[type=checkbox] {
            accent-color: var(--accent, #007aff);
            width: 15px; height: 15px;
            cursor: pointer;
        }
        .charts-range-inputs {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 6px;
            transition: opacity .2s;
        }
        .charts-range-inputs input[type=datetime-local] {
            font-size: .82rem;
            padding: 3px 6px;
            border: 1px solid var(--border, #d1d1d6);
            border-radius: var(--r-sm, 6px);
            background: var(--surface, #fff);
            color: var(--text-1, #333);
        }
        .charts-range-sep {
            color: var(--text-3, #aaa);
            user-select: none;
        }
        .charts-range-disabled {
            opacity: 0.38;
            pointer-events: none;
        }
        /* Export buttons group */
        .charts-export-btns {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-shrink: 0;
            border-left: 1px solid var(--border, #d1d1d6);
            padding-left: 16px;
        }
        .charts-export-label {
            font-size: .78rem;
            color: var(--text-3, #aaa);
            white-space: nowrap;
            user-select: none;
        }
        .btn-charts {
            padding: 4px 11px;
            cursor: pointer;
            border: 1px solid var(--border, #d1d1d6);
            border-radius: var(--r-sm, 6px);
            background: var(--surface, #fff);
            color: var(--text-1, #333);
            font-size: .82rem;
            transition: background .15s;
        }
        .btn-charts:hover { background: var(--surface-3, #ebebed); }
        @media (max-width: 600px) {
            .charts-export-btns {
                border-left: none;
                padding-left: 0;
                border-top: 1px solid var(--border, #d1d1d6);
                padding-top: 8px;
                width: 100%;
            }
        }
    `;document.head.appendChild(style);container.parentNode.insertBefore(panel,container);}
function CreateChart(){if(typeof Highcharts!=='undefined'){Highcharts.setOptions({time:{useUTC:false}});}
injectControls();let allPoints=[];let chart=null;const cs=prop=>getComputedStyle(document.documentElement).getPropertyValue(prop).trim();function buildOptions(points){return{chart:{type:'line',backgroundColor:cs('--bg-color'),reflow:true,animation:false},title:{text:'CO\u2082 \u2013 mediciones recientes',style:{color:cs('--title-color')}},xAxis:{type:'datetime',labels:{format:'{value:%d/%m %H:%M}',style:{color:cs('--font-color')}}},yAxis:{title:{text:'CO\u2082 (ppm)',style:{color:cs('--font-color')}},labels:{style:{color:cs('--font-color')}}},series:[{name:'CO\u2082',data:points,color:cs('--title-color'),marker:{enabled:points.length<120}}],tooltip:{xDateFormat:'%d/%m/%Y %H:%M:%S'},exporting:{enabled:false},legend:{itemStyle:{color:cs('--font-color')}},credits:{enabled:false},responsive:{rules:[{condition:{maxWidth:500},chartOptions:{xAxis:{labels:{format:'{value:%H:%M}'}}}}]}};}
function renderChart(points){if(chart){chart.series[0].setData(points,true,false,false);}else{chart=Highcharts.chart('container',buildOptions(points));}}
function isFilterEnabled(){const cb=document.getElementById('charts-filter-enabled');return cb&&cb.checked;}
function getRange(){const fromInput=document.getElementById('charts-from');const toInput=document.getElementById('charts-to');const fromTs=fromInput&&fromInput.value?new Date(fromInput.value).getTime():-Infinity;const toTs=toInput&&toInput.value?new Date(toInput.value).getTime():Infinity;return{fromTs,toTs};}
function applyFilter(){if(!allPoints.length)return;if(!isFilterEnabled()){renderChart(allPoints);return;}
const{fromTs,toTs}=getRange();const pts=filterPoints(allPoints,fromTs,toTs);renderChart(pts.length?pts:allPoints);}
function populateRangeInputs(){if(!allPoints.length)return;const fromInput=document.getElementById('charts-from');const toInput=document.getElementById('charts-to');if(fromInput)fromInput.value=tsToDatetimeLocal(allPoints[0][0]);if(toInput)toInput.value=tsToDatetimeLocal(allPoints[allPoints.length-1][0]);}
const filterCb=document.getElementById('charts-filter-enabled');const rangeDiv=document.getElementById('charts-range-inputs');if(filterCb){filterCb.addEventListener('change',()=>{if(filterCb.checked){rangeDiv.classList.remove('charts-range-disabled');populateRangeInputs();}else{rangeDiv.classList.add('charts-range-disabled');renderChart(allPoints);}});}
document.getElementById('charts-apply').addEventListener('click',applyFilter);function exportCSV(){const{fromTs,toTs}=getRange();const pts=isFilterEnabled()?filterPoints(allPoints,fromTs,toTs):allPoints;const rows=[['Timestamp','CO2_ppm']].concat(pts.map(([ts,v])=>[new Date(ts).toISOString(),v]));downloadText('co2_data.csv',rows.map(r=>r.join(',')).join('\n'));}
function exportJSON(){const{fromTs,toTs}=getRange();const pts=isFilterEnabled()?filterPoints(allPoints,fromTs,toTs):allPoints;downloadText('co2_data.json',JSON.stringify(pts.map(([ts,v])=>({timestamp:new Date(ts).toISOString(),co2_ppm:v})),null,2));}
document.getElementById('charts-csv').addEventListener('click',exportCSV);document.getElementById('charts-json').addEventListener('click',exportJSON);document.getElementById('charts-png').addEventListener('click',()=>{if(chart)chart.exportChart({type:'image/png',filename:'co2_data'});});document.getElementById('charts-svg').addEventListener('click',()=>{if(chart)chart.exportChart({type:'image/svg+xml',filename:'co2_data'});});document.addEventListener('themeChange',()=>{if(!chart)return;chart.update({chart:{backgroundColor:cs('--bg-color')},title:{style:{color:cs('--title-color')}},xAxis:{labels:{style:{color:cs('--font-color')}}},yAxis:{title:{style:{color:cs('--font-color')}},labels:{style:{color:cs('--font-color')}}},series:[{color:cs('--title-color')}],legend:{itemStyle:{color:cs('--font-color')}}},true,false,false);});window.addEventListener('resize',()=>{if(chart)chart.reflow();});function fetchAndRender(){fetchWithTimeout('/circularBufferData',{},10000).then(r=>{if(!r.ok)throw new Error('Response not OK: '+r.status);return r.json();}).then(data=>{allPoints=buildPoints(data);applyFilter();}).catch(err=>console.error('Error fetching chart data:',err));}
fetchAndRender();setInterval(fetchAndRender,60000);}
document.addEventListener('DOMContentLoaded',function(){if(window.location.href.includes('charts.html')||window.location.pathname==='/charts.html'){if(typeof highlightCurrentPage==='function')highlightCurrentPage();CreateChart();}});