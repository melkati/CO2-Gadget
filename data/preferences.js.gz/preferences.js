﻿/**
 * Debug flag for captive portal.
 * @type {boolean}
 */
var captivePortalDebug = false;

/**
 * Flag to force captive portal debug mode.
 * @type {boolean}
 */
var forcedCaptivePortalDebug = false;

/**
 * Flag indicating if the captive portal is active.
 * @type {boolean}
 */
var captivePortalActive = false;

/**
 * Flag to force the captive portal to be active.
 * @type {boolean}
 */
var forcedCaptivePortal = false;

/**
 * Flag indicating if the captive portal has no timeout.
 * @type {boolean}
 */
var captivePortalNoTimeout = false;

/**
 * Flag to force the captive portal to have no timeout.
 * @type {boolean}
 */
var forcedCaptivePortalNoTimeout = false;

/**
 * Flag to control relaxed security mode.
 * @type {boolean}
 */
var relaxedSecurity = false;

/**
 * Flag enabled by the URL parameter "relaxedSecurity" to force relaxed security mode.
 * @type {boolean}
 */
var forcedRelaxedSecurity = false;

/**
 * Flag to control captive portal test mode.
 * @type {boolean}
 */
var forceCaptivePortalActive = false;

/**
 * Flag to enable debug output in the console for preferences.
 * @type {boolean}
 */
var preferencesDebug = false;

/**
 * Global object to store the captive portal status.
 * @type {Object}
 * @property {number} captivePortalTimeLeft - Time left for the captive portal.
 */
var captivePortalStatus = {
    captivePortalTimeLeft: 0
};

/**
 * Global object to store the previous state.
 * @type {Object}
 * @property {boolean} forceCaptivePortalActive - Previous state of forceCaptivePortalActive.
 * @property {boolean} captivePortalActive - Previous state of captivePortalActive.
 * @property {boolean} forcedCaptivePortal - Previous state of forcedCaptivePortal.
 * @property {boolean} captivePortalDebug - Previous state of captivePortalDebug.
 * @property {boolean} relaxedSecurity - Previous state of relaxedSecurity.
 * @property {boolean} forcedCaptivePortalDebug - Previous state of forcedCaptivePortalDebug.
 * @property {boolean} captivePortalNoTimeout - Previous state of captivePortalNoTimeout.
 */
var previousData = {
    forceCaptivePortalActive: false,
    captivePortalActive: false,
    forcedCaptivePortal: false,
    captivePortalDebug: false,
    relaxedSecurity: false,
    forcedCaptivePortalDebug: false,
    captivePortalNoTimeout: false
};

/**
 * Global object to store the CO2 Gadget features supported by the device (selected at compile time).
 * @type {Object}
 * @property {boolean} SUPPORT_BLE - Whether BLE is supported.
 * @property {boolean} SUPPORT_BTHOME_BLE - Whether BTHome BLE is supported.
 * @property {boolean} SUPPORT_BUZZER - Whether a buzzer is supported.
 * @property {boolean} SUPPORT_ESPNOW - Whether ESP-NOW is supported.
 * @property {boolean} SUPPORT_MDNS - Whether mDNS is supported.
 * @property {boolean} SUPPORT_MQTT - Whether MQTT is supported.
 * @property {boolean} SUPPORT_MQTT_DISCOVERY - Whether MQTT Discovery is supported.
 * @property {boolean} SUPPORT_OTA - Whether OTA updates are supported.
 * @property {boolean} SUPPORT_LOW_POWER - Whether low power mode is supported.
 * @property {boolean} SUPPORT_CIRCULAR_BUFFER - Whether circular buffer (charts) is supported.
 */
var features = {
    SUPPORT_BLE: false,
    SUPPORT_BTHOME_BLE: false,
    SUPPORT_BUZZER: false,
    SUPPORT_ESPNOW: false,
    SUPPORT_MDNS: false,
    SUPPORT_MQTT: false,
    SUPPORT_MQTT_DISCOVERY: false,
    SUPPORT_OTA: false,
    SUPPORT_LOW_POWER: false,
    SUPPORT_CIRCULAR_BUFFER: false
};

/**
 * Wrapper around fetch() that automatically aborts after timeoutMs milliseconds.
 * Prevents hung requests from blocking the retry logic when the ESP32 is busy
 * (e.g. during an EINK refresh or CO2 measurement cycle).
 * @param {string} url - The URL to fetch.
 * @param {RequestInit} [options] - Standard fetch options.
 * @param {number} [timeoutMs=6000] - Abort timeout in milliseconds.
 * @returns {Promise<Response>}
 */
function fetchWithTimeout(url, options, timeoutMs) {
    if (timeoutMs === undefined) timeoutMs = 6000;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    const fetchOptions = Object.assign({}, options || {}, { signal: controller.signal });
    return fetch(url, fetchOptions)
        .then(function(response) { clearTimeout(timeoutId); return response; })
        .catch(function(error) { clearTimeout(timeoutId); throw error; });
}

/**
 * Restarts the ESP32 device after user confirmation.
 */
function restartESP32() {
    const isConfirmed = confirm("Are you sure you want to restart the ESP32?");
    if (isConfirmed) {
        if (preferencesDebug) console.log("Restarting ESP32...");
        fetchWithTimeout('/restart', { method: 'GET', headers: { 'Content-Type': 'text/plain' } }, 5000)
            .then(response => {
                if (response.ok) {
                    console.log('ESP32 restart initiated');
                } else {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
            })
            .catch(error => console.error('Error restarting ESP32:', error));
    }
}

/**
 * Adds the 'active' class to the current page link in the navigation bar.
 */
function highlightCurrentPage() {
    const currentPage = window.location.pathname.split("/").pop();
    const navLinks = document.querySelectorAll(".navbar .nav-content a");

    navLinks.forEach(link => {
        if (link.getAttribute("href") === currentPage) {
            link.classList.add("active");
        }
    });
}

/**
 * Loads features from the server and updates the global features object.
 */
function loadFeaturesFromServer() {
    fetchWithTimeout('/getFeaturesAsJson', {}, 8000)
        .then(response => response.json())
        .then(data => {
            console.log('Fetching loadFeaturesFromServer successful!');
            features.SUPPORT_BLE = data.BLE !== undefined ? data.BLE : false;
            features.SUPPORT_BTHOME_BLE = data.BTHomeBLE !== undefined ? data.BTHomeBLE : false;
            features.SUPPORT_BUZZER = data.Buzzer !== undefined ? data.Buzzer : false;
            features.SUPPORT_ESPNOW = data.EspNow !== undefined ? data.EspNow : false;
            features.SUPPORT_MDNS = data.mDNS !== undefined ? data.mDNS : false;
            features.SUPPORT_MQTT = data.MQTT !== undefined ? data.MQTT : false;
            features.SUPPORT_MQTT_DISCOVERY = data.MQTTDiscovery !== undefined ? data.MQTTDiscovery : false;
            features.SUPPORT_OTA = data.OTA !== undefined ? data.OTA : false;
            features.SUPPORT_LOW_POWER = data.LowPower !== undefined ? data.LowPower : false;
            features.SUPPORT_CIRCULAR_BUFFER = data.CircularBuffer !== undefined ? data.CircularBuffer : false;
        })
        .catch(error => console.error('Error fetching features:', error));
}

/**
 * Fetches the battery voltage from the server.
 * @returns {Promise<string>} A promise that resolves to the battery voltage as a string.
 * @throws {Error} If the network response is not ok or if there is an error fetching the data.
 */
function readBatteryVoltage() {
    return fetchWithTimeout('/readBatteryVoltage', {}, 5000)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok.');
            return response.text();
        })
        .catch(error => {
            console.error('Error fetching battery voltage:', error);
            throw error;
        });
}

/**
 * Fetches CO2 data from the server.
 * @returns {Promise<string>} A promise that resolves to the CO2 value as a string.
 */
function readCO2Data() {
    return fetchWithTimeout('/readCO2', {}, 5000)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok.');
            return response.text();
        })
        .then(data => parseFloat(data))
        .catch(error => {
            console.error("Error fetching CO2 data:", error);
            throw error;
        });
}

/**
 * Fetches temperature data from the server.
 * @returns {Promise<number>} A promise that resolves to the temperature value.
 */
function readTemperatureData() {
    return fetchWithTimeout('/readTemperature', {}, 5000)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok.');
            return response.text();
        })
        .then(data => parseFloat(data).toFixed(1))
        .catch(error => {
            console.error("Error fetching temperature data:", error);
            throw error;
        });
}

/**
 * Fetches humidity data from the server.
 * @returns {Promise<string>} A promise that resolves to the humidity value as a string.
 */
function readHumidityData() {
    return fetchWithTimeout('/readHumidity', {}, 5000)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok.');
            return response.text();
        })
        .then(data => parseFloat(data).toFixed(0))
        .catch(error => {
            console.error("Error fetching humidity data:", error);
            throw error;
        });
}

/**
 * Reads the measurement interval from the server.
 * @returns {Promise<number>} A promise that resolves to the measurement interval in milliseconds.
 * @throws {Error} If the network response is not ok or an error occurs during the fetch operation.
 */
function readMeasurementInterval() {
    return fetchWithTimeout('/getMeasurementInterval', {}, 5000)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok.');
            return response.text();
        })
        .then(data => parseInt(data) * 1000)
        .catch(error => {
            console.error("Error fetching measurement interval:", error);
            throw error;
        });
}

/**
 * Fetches the free heap memory from the server.
 * @returns {Promise<string>} A promise that resolves to the free heap memory as a string.
 * @throws {Error} If the network response is not ok or if there is an error fetching the data.
 */
function readFreeHeap() {
    return fetchWithTimeout('/getFreeHeap', {}, 5000)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok.');
            return response.text();
        })
        .catch(error => {
            console.error('Error fetching free heap:', error);
            throw error;
        });
}

/**
 * Fetches the minimum free heap memory from the server.
 * @returns {Promise<string>} A promise that resolves to the minimum free heap memory as a string.
 * @throws {Error} If the network response is not ok or if there is an error fetching the data.
 */
function readMinFreeHeap() {
    return fetchWithTimeout('/getMinFreeHeap', {}, 5000)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok.');
            return response.text();
        })
        .catch(error => {
            console.error('Error fetching min free heap:', error);
            throw error;
        });
}

/**
 * Handles the features data and updates the SUPPORT_* properties accordingly.
 * @param {Object} data - The features data object.
 */
function handleFeaturesData(data) {
    features.SUPPORT_BLE = data.BLE !== undefined ? data.BLE : false;
    features.SUPPORT_BTHOME_BLE = data.BTHomeBLE !== undefined ? data.BTHomeBLE : false;
    features.SUPPORT_BUZZER = data.Buzzer !== undefined ? data.Buzzer : false;
    features.SUPPORT_ESPNOW = data.EspNow !== undefined ? data.EspNow : false;
    features.SUPPORT_MDNS = data.mDNS !== undefined ? data.mDNS : false;
    features.SUPPORT_MQTT = data.MQTT !== undefined ? data.MQTT : false;
    features.SUPPORT_MQTT_DISCOVERY = data.MQTTDiscovery !== undefined ? data.MQTTDiscovery : false;
    features.SUPPORT_OTA = data.OTA !== undefined ? data.OTA : false;
    features.SUPPORT_LOW_POWER = data.LowPower !== undefined ? data.LowPower : false;
    features.SUPPORT_CIRCULAR_BUFFER = data.CircularBuffer !== undefined ? data.CircularBuffer : false;

    if (captivePortalDebug) console.log('Mapped Features:', features);
}

/**
 * Fetches features as JSON from the server and processes the data.
 * @returns {Promise<void>}
 */
function getFeaturesAsJson() {
    return fetchWithTimeout('/getFeaturesAsJson', {}, 8000)
        .then(response => {
            if (!response.ok) {
                console.error('Response not OK:', response.status, response.statusText);
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            console.log("Received JSON:", data);
            handleFeaturesData(data);
        })
        .catch(error => {
            console.error("Error fetching CO2 Gadget features:", error);
        });
}

/**
 * Fetches the version information from the server.
 * @returns {Promise<Object>} A promise that resolves to the version information object.
 * @throws {Error} If the network response is not ok or if there is an error fetching the version.
 */
function fetchVersion() {
    return fetchWithTimeout('/getVersion', {}, 8000)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok.');
            return response.json();
        })
        .then(data => {
            if (captivePortalDebug) console.log('Version information:', data);
            return data;
        })
        .catch(error => {
            console.error('Error fetching version:', error);
            throw error;
        });
}

/**
 * Retrieves the version string of the firmware.
 * @returns {Promise<string>} A promise that resolves to the version string.
 * @throws {Error} If there is an error getting the version string.
 */
function getVersionStr() {
    return fetchVersion()
        .then(versionInfo => {
            let versionText = `v${versionInfo.firmVerMajor}.${versionInfo.firmVerMinor}.${versionInfo.firmRevision}`;
            if (versionInfo.firmBranch) {
                versionText += `-${versionInfo.firmBranch}`;
            }
            versionText += ` (Flavour: ${versionInfo.firmFlavour})`;
            if (versionInfo.firmBuildDate) versionText += ` \u2014 Built: ${versionInfo.firmBuildDate}`;
            if (versionInfo.firmBuildTime) versionText += ` at ${versionInfo.firmBuildTime}`;
            if (captivePortalDebug) console.log('Version string:', versionText);
            return versionText;
        })
        .catch(error => {
            console.error('Error getting version as string:', error);
            throw error;
        });
}

/**
 * Retrieves a JSON from the server with the current settings
 * and returns a promise that resolves to the JSON object.
 * Uses AbortController to enforce an 8-second timeout so that a hung
 * request (e.g. when the device is busy with a CO2 measurement or EINK
 * render) is rejected promptly and the retry logic can kick in.
 * @returns {Promise<Object>} A promise that resolves to the settings JSON object.
 */
function readPreferencesFromServer() {
    return fetchWithTimeout('/getActualSettingsAsJson', {}, 8000)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok.');
            return response.json();
        })
        .catch(error => {
            console.error('Error fetching preferences:', error);
            throw error;
        });
}

/**
 * Initialize the navbar based on the features supported by the device.
 */
function initNavBar() {
    if (captivePortalDebug)
        console.log("Document loaded. Initializing navbar...");

    if (features.SUPPORT_OTA) {
        const otaBadge = document.getElementById("otaBadge");
        if (otaBadge) otaBadge.classList.remove("hidden");
        const maintenanceSection = document.getElementById("maintenanceSection");
        if (maintenanceSection) maintenanceSection.classList.remove("hidden");
    }

    if (features.SUPPORT_CIRCULAR_BUFFER) {
        const chartsLink = document.getElementById("chartsLink");
        if (chartsLink) {
            chartsLink.classList.remove("hidden");
        } else {
            console.error('Element with ID "chartsLink" not found.')
        }
    }

    const lowPowerIcon = document.getElementById("lightingIcon");
    if (lowPowerIcon) lowPowerIcon.classList.toggle("hidden", !features.SUPPORT_LOW_POWER);
}

/**
 * Handles the low power mode activation.
 */
function goLowPower() {
    if (!features.SUPPORT_LOW_POWER) {
        console.warn('Low power support is not compiled into this firmware.');
        return;
    }
    console.log('Low power mode activated');
    fetchWithTimeout('/goLowPower', { method: 'GET', headers: { 'Content-Type': 'text/plain' } }, 5000)
        .then(response => {
            if (response.ok) {
                console.log('Low power mode activated');
            } else {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
        })
        .catch(error => console.error('Error activating low power mode:', error));
}

document.addEventListener("DOMContentLoaded", function () {
    getFeaturesAsJson().then(initNavBar);

    // Add device hostName to the existing page title as document.title + (HostName)
    readPreferencesFromServer().then(data => {
        if (data && data.hostName) document.title += ` (${data.hostName})`;
    }).catch(error => console.warn('Could not get hostName for title:', error));

    // Low power icon click handler (element may not be present in all pages)
    const lightingIcon = document.getElementById('lightingIcon');
    if (lightingIcon) lightingIcon.addEventListener('click', goLowPower);

    initFullscreen();
});

/* =========================================================
   Fullscreen management
   ========================================================= */
const _fsExpandPath  = "M32 32C14.3 32 0 46.3 0 64v96c0 17.7 14.3 32 32 32s32-14.3 32-32V96h64c17.7 0 32-14.3 32-32s-14.3-32-32-32H32zM64 352c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7 14.3 32 32 32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H64V352zM320 32c-17.7 0-32 14.3-32 32s14.3 32 32 32h64v64c0 17.7 14.3 32 32 32s32-14.3 32-32V64c0-17.7-14.3-32-32-32H320zM448 352c0-17.7-14.3-32-32-32s-32 14.3-32 32v64H320c-17.7 0-32 14.3-32 32s14.3 32 32 32h96c17.7 0 32-14.3 32-32V352z";
const _fsCompressPath = "M160 64c0-17.7-14.3-32-32-32s-32 14.3-32 32v64H32c-17.7 0-32 14.3-32 32s14.3 32 32 32h96c17.7 0 32-14.3 32-32V64zM32 320c-17.7 0-32 14.3-32 32s14.3 32 32 32H96v64c0 17.7 14.3 32 32 32s32-14.3 32-32V352c0-17.7-14.3-32-32-32H32zM352 64c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7 14.3 32 32 32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H352V64zM320 320c-17.7 0-32 14.3-32 32v96c0 17.7 14.3 32 32 32s32-14.3 32-32V352h64c17.7 0 32-14.3 32-32s-14.3-32-32-32H320z";

function initFullscreen() {
    const btn    = document.getElementById('iconFullscreen');
    if (!btn) return;
    const fspath = document.getElementById('fullscreenPath');
    const fsicon = document.getElementById('fullscreenIcon');
    const navbar = document.getElementById('navbar');
    let hideTimer = null;

    function updateFsIcon(isFs) {
        if (!fspath || !fsicon) return;
        fsicon.setAttribute('viewBox', '0 0 448 512');
        fspath.setAttribute('d', isFs ? _fsCompressPath : _fsExpandPath);
    }

    function showNavbar() {
        if (!navbar) return;
        navbar.classList.add('fs-nav-visible');
        clearTimeout(hideTimer);
        hideTimer = setTimeout(() => navbar.classList.remove('fs-nav-visible'), 2500);
    }

    btn.addEventListener('click', () => {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(() => {});
        } else {
            document.exitFullscreen().catch(() => {});
        }
    });

    document.addEventListener('fullscreenchange', () => {
        const isFs = !!document.fullscreenElement;
        updateFsIcon(isFs);
        document.body.classList.toggle('is-fullscreen', isFs);
        if (isFs) {
            showNavbar();
            document.addEventListener('mousemove', showNavbar);
        } else {
            clearTimeout(hideTimer);
            if (navbar) navbar.classList.remove('fs-nav-visible');
            document.removeEventListener('mousemove', showNavbar);
        }
    });
}

/* =========================================================
   Timezone helpers — stored in localStorage as 'co2gadget_tz'
   Value is UTC offset in decimal hours (e.g. 1, -5, 5.5)
   ========================================================= */

/**
 * Returns stored UTC offset in hours, or browser's current UTC offset if not set.
 * @returns {number} UTC offset in decimal hours
 */
function getTzOffsetHours() {
    const stored = localStorage.getItem('co2gadget_tz');
    if (stored !== null && stored !== '') return parseFloat(stored);
    return -new Date().getTimezoneOffset() / 60;
}

/**
 * Returns the millisecond shift needed to convert a UTC timestamp (Date.now())
 * to the stored local timezone for display.
 * @returns {number} offset in ms
 */
function getTzOffsetMs() {
    return getTzOffsetHours() * 3600000;
}

/**
 * Saves a UTC offset (decimal hours) to localStorage and triggers a custom event.
 * @param {string|number} offsetHours
 */
function saveTzOffset(offsetHours) {
    localStorage.setItem('co2gadget_tz', String(offsetHours));
    document.dispatchEvent(new CustomEvent('tzChange', { detail: { offset: parseFloat(offsetHours) } }));
}

/**
 * Formats a UTC epoch timestamp (ms) as 'HH:mm:ss' in the stored timezone.
 * @param {number} utcMs  — pure UTC milliseconds (Date.now())
 * @returns {string}
 */
function formatTimeInTz(utcMs) {
    const pad = n => String(n).padStart(2, '0');
    const d = new Date(utcMs + getTzOffsetMs());
    return pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()) + ':' + pad(d.getUTCSeconds());
}

/**
 * Formats a UTC epoch timestamp (ms) as 'yyyy-MM-ddTHH:mm' in the stored timezone.
 * @param {number} utcMs  — pure UTC milliseconds
 * @returns {string}
 */
function formatDatetimeLocalInTz(utcMs) {
    const pad = n => String(n).padStart(2, '0');
    const d = new Date(utcMs + getTzOffsetMs());
    return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()) +
        'T' + pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes());
}

/**
 * Returns a human-readable UTC offset label, e.g. 'UTC+2' or 'UTC−5'.
 * @param {number} offsetHours
 * @returns {string}
 */
function tzOffsetLabel(offsetHours) {
    const sign = offsetHours >= 0 ? '+' : '−';
    const abs = Math.abs(offsetHours);
    const h = Math.floor(abs);
    const m = Math.round((abs - h) * 60);
    return 'UTC' + sign + String(h) + (m ? ':' + String(m).padStart(2, '0') : '');
}

const lightThemeIconPath = `M375.7 19.7c-1.5-8-6.9-14.7-14.4-17.8s-16.1-2.2-22.8 2.4L256 61.1 173.5 4.2c-6.7-4.6-15.3-5.5-22.8-2.4s-12.9 9.8-14.4 17.8l-18.1 98.5L19.7 136.3c-8 1.5-14.7 6.9-17.8 14.4s-2.2 16.1 2.4 22.8L61.1 256 4.2 338.5c-4.6 6.7-5.5 15.3-2.4 22.8s9.8 13 17.8 14.4l98.5 18.1 18.1 98.5c1.5 8 6.9 14.7 14.4 17.8s16.1 2.2 22.8-2.4L256 450.9l82.5 56.9c6.7 4.6 15.3 5.5 22.8 2.4s12.9-9.8 14.4-17.8l18.1-98.5 98.5-18.1c8-1.5 14.7-6.9 17.8-14.4s2.2-16.1-2.4-22.8L450.9 256l56.9-82.5c4.6-6.7 5.5-15.3 2.4-22.8s-9.8-12.9-17.8-14.4l-98.5-18.1L375.7 19.7zM269.6 110l65.6-45.2 14.4 78.3c1.8 9.8 9.5 17.5 19.3 19.3l78.3 14.4L402 242.4c-5.7 8.2-5.7 19 0 27.2l45.2 65.6-78.3 14.4c-9.8 1.8-17.5 9.5-19.3 19.3l-14.4 78.3L269.6 402c-8.2-5.7-19-5.7-27.2 0l-65.6 45.2-14.4-78.3c-1.8-9.8-9.5-17.5-19.3-19.3L64.8 335.2 110 269.6c5.7-8.2 5.7-19 0-27.2L64.8 176.8l78.3-14.4c9.8-1.8 17.5-9.5 19.3-19.3l14.4-78.3L242.4 110c8.2 5.7 19 5.7 27.2 0zM256 368a112 112 0 1 0 0-224 112 112 0 1 0 0 224zM192 256a64 64 0 1 1 128 0 64 64 0 1 1 -128 0z`;
const darkThemeIconPath = `M144.7 98.7c-21 34.1-33.1 74.3-33.1 117.3c0 98 62.8 181.4 150.4 211.7c-12.4 2.8-25.3 4.3-38.6 4.3C126.6 432 48 353.3 48 256c0-68.9 39.4-128.4 96.8-157.3zm62.1-66C91.1 41.2 0 137.9 0 256C0 379.7 100 480 223.5 480c47.8 0 92-15 128.4-40.6c1.9-1.3 3.7-2.7 5.5-4c4.8-3.6 9.4-7.4 13.9-11.4c2.7-2.4 5.3-4.8 7.9-7.3c5-4.9 6.3-12.5 3.1-18.7s-10.1-9.7-17-8.5c-3.7 .6-7.4 1.2-11.1 1.6c-5 .5-10.1 .9-15.3 1c-1.2 0-2.5 0-3.7 0c-.1 0-.2 0-.3 0c-96.8-.2-175.2-78.9-175.2-176c0-54.8 24.9-103.7 64.1-136c1-.9 2.1-1.7 3.2-2.6c4-3.2 8.2-6.2 12.5-9c3.1-2 6.3-4 9.6-5.8c6.1-3.5 9.2-10.5 7.7-17.3s-7.3-11.9-14.3-12.5c-3.6-.3-7.1-.5-10.7-.6c-2.7-.1-5.5-.1-8.2-.1c-3.3 0-6.5 .1-9.8 .2c-2.3 .1-4.6 .2-6.9 .4z`;

const lightLowPowerIconPath = `M0 256L28.5 28c2-16 15.6-28 31.8-28H228.9c15 0 27.1 12.1 27.1 27.1c0 3.2-.6 6.5-1.7 9.5L208 160H347.3c20.2 0 36.7 16.4 36.7 36.7c0 7.4-2.2 14.6-6.4 20.7l-192.2 281c-5.9 8.6-15.6 13.7-25.9 13.7h-2.9c-15.7 0-28.5-12.8-28.5-28.5c0-2.3 .3-4.6 .9-6.9L176 288H32c-17.7 0-32-14.3-32-32z`;
const darkLowPowerIconPath = `M0 256L28.5 28c2-16 15.6-28 31.8-28H228.9c15 0 27.1 12.1 27.1 27.1c0 3.2-.6 6.5-1.7 9.5L208 160H347.3c20.2 0 36.7 16.4 36.7 36.7c0 7.4-2.2 14.6-6.4 20.7l-192.2 281c-5.9 8.6-15.6 13.7-25.9 13.7h-2.9c-15.7 0-28.5-12.8-28.5-28.5c0-2.3 .3-4.6 .9-6.9L176 288H32c-17.7 0-32-14.3-32-32z`;

/**
 * Set the theme icon based on the current theme.
 * @param {string} theme - The current theme ("light" or "dark").
 */
function setThemeIcon(theme) {
    const iconPath = document.getElementById("iconPath");
    const themeIcon = document.getElementById("themeIcon");
    if (theme === "dark") {
        themeIcon.setAttribute("viewBox", "0 0 384 512");
        iconPath.setAttribute("d", darkThemeIconPath);
    } else {
        themeIcon.setAttribute("viewBox", "0 0 512 512");
        iconPath.setAttribute("d", lightThemeIconPath);
    }
}

/**
 * Set the low power icon based on the current theme.
 * @param {string} theme - The current theme ("light" or "dark").
 */
function setLowPowerIcon(theme) {
    const iconPathLowPower = document.getElementById("iconPathLowPower");
    const lowPowerIcon = document.getElementById("lightingIcon");
    if (!lowPowerIcon || !iconPathLowPower) return;
    if (theme === "dark") {
        lowPowerIcon.setAttribute("viewBox", "0 0 384 512");
        iconPathLowPower.setAttribute("d", darkLowPowerIconPath);
    } else {
        lowPowerIcon.setAttribute("viewBox", "0 0 384 512");
        iconPathLowPower.setAttribute("d", lightLowPowerIconPath);
    }
}

/**
 * Toggle between light and dark themes.
 */
function toggleTheme() {
    const htmlElement = document.documentElement;
    const currentTheme = htmlElement.getAttribute("theme");
    const newTheme = currentTheme === "dark" ? "light" : "dark";
    console.debug("Toggle theme function called");
    console.debug("Current theme:", currentTheme);
    console.debug("New theme:", newTheme);
    htmlElement.setAttribute("theme", newTheme);
    console.debug("Theme set to:", newTheme);
    localStorage.setItem("theme", newTheme);
    setThemeIcon(newTheme);
    setLowPowerIcon(newTheme);
}

/**
 * Initialize the theme based on the saved preference in localStorage.
 */
function initializeTheme() {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme) {
        document.documentElement.setAttribute("theme", savedTheme);
        setThemeIcon(savedTheme);
        setLowPowerIcon(savedTheme);
    } else {
        setThemeIcon('light'); // Default theme
        setLowPowerIcon('light'); // Default low power icon
    }
}

/**
 * Initialize the theme switch event listener.
 */
function initializeThemeSwitch() {
    const colorSwitch = document.querySelector("#iconBulb");
    if (colorSwitch) {
        colorSwitch.addEventListener("click", toggleTheme);
    } else {
        console.error('Element with ID "iconBulb" not found.');
    }
}

document.addEventListener("DOMContentLoaded", function () {
    initializeTheme();
    initializeThemeSwitch();

    // Low power icon click handler (element removed from most pages — null-safe)
    const _li = document.getElementById('lightingIcon');
    if (_li) _li.addEventListener('click', goLowPower);
});

/**
 * Sets the captive portal settings and sends them to the server.
 * @param {number} timeToWait - The time to wait for the captive portal.
 * @param {boolean} isInitialSetup - Whether this is the initial setup.
 */
function setCaptivePortalSettings(timeToWait, isInitialSetup = false) {

    // captivePortalNoTimeout is not loaded with the form value to obey the override from the URL

    // const disableTimeoutCheckbox = document.getElementById('cpNoTimeout');
    // captivePortalNoTimeout = disableTimeoutCheckbox ? disableTimeoutCheckbox.checked : false;

    // if (!disableTimeoutCheckbox && !isInitialSetup) {
    //     console.error('Element with ID "cpNoTimeout" not found.');
    //     return;
    // }

    // if (captivePortalDebug) {
    //     console.log('Setting captivePortalNoTimeout to:', captivePortalNoTimeout);
    //     console.log('Time to wait for timeout:', timeToWait);
    // }

    // if (disableTimeoutCheckbox && disableTimeoutCheckbox.checked) {
    //     if (captivePortalDebug || forcedCaptivePortalDebug) console.log('Disabling timeout for captive portal');
    //     timeToWait = 0;
    //     captivePortalNoTimeout = true;
    // }

    fetchWithTimeout('/setCaptivePortalSettings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            timeToWaitForCaptivePortal: timeToWait,
            captivePortalActive,
            captivePortalNoTimeout,
            forcedCaptivePortal,
            captivePortalDebug,
            relaxedSecurity: relaxedSecurity ? true : undefined
        })
    }, 5000)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            if (captivePortalDebug) {
                console.log('Captive Portal settings updated on server successfully:', {
                    forcedCaptivePortal,
                    captivePortalActive,
                    captivePortalNoTimeout,
                    timeToWaitForCaptivePortal: timeToWait,
                    captivePortalDebug,
                    relaxedSecurity
                });
            }
        })
        .catch(error => console.error('Error setting captive portal settings:', error));
}

/**
 * Stores the captive portal status in the captivePortalStatus object.
 * @param {Object} data - The data containing the captive portal status.
 */
function storeCaptivePortalStatus(data) {
    captivePortalStatus.captivePortalTimeLeft = data.captivePortalTimeLeft;
}

/**
 * Handles the response data from the captive portal status fetch and updates the UI.
 * @param {Object} data - The data received from the server.
 */
function handleCaptivePortalData(data) {
    try {
        storeCaptivePortalStatus(data);
        const changes = checkForPropertyChanges(data);
        logPropertyChanges(changes);

        updateDebugMode(data);
        updateActiveStates(data);
        // updateStatusBarContent();

        if (debugWindowActive) {
            updateDebugWindow(data);
        }
    } catch (error) {
        console.error('Error in handleCaptivePortalData function:', error);
        throw error;
    }
}

/**
 * Checks for changes in specific properties compared to previous data.
 * @param {Object} data - The data received from the server.
 * @returns {Object} - Object containing changes in properties.
 */
function checkForPropertyChanges(data) {
    const changes = {};
    const propertiesToCheck = ['forceCaptivePortalActive', 'captivePortalActive', 'forcedCaptivePortal', 'captivePortalDebug', 'relaxedSecurity', 'forcedCaptivePortalDebug', 'captivePortalNoTimeout'];

    propertiesToCheck.forEach(key => {
        if (data[key] !== previousData[key]) {
            changes[key] = { previous: previousData[key], current: data[key] };
            previousData[key] = data[key];
        }
    });

    return changes;
}

/**
 * Logs changes in properties to the console.
 * @param {Object} changes - Object containing changes in properties.
 */
function logPropertyChanges(changes) {
    if (Object.keys(changes).length > 0) {
        console.log('Detected changes in captive portal data:', changes);
    }
}

/**
 * Updates the debug mode if present in the data.
 * @param {Object} data - The data received from the server.
 */
function updateDebugMode(data) {
    if (data.captivePortalDebug !== undefined) {
        if (data.captivePortalDebug !== captivePortalDebug) {
            captivePortalDebug = data.captivePortalDebug;
            console.log('Captive portal debug mode set to:', captivePortalDebug);
        }
    }
}

/**
 * Updates the active states based on the data received.
 * @param {Object} data - The data received from the server.
 */
function updateActiveStates(data) {
    forcedCaptivePortal = data.forceCaptivePortalActive || false;
    captivePortalActive = (data.captivePortalActive || false) || forcedCaptivePortal;
}

/**
 * Fetches the captive portal settings from the server.
 */
function getCaptivePortalSettings() {
    fetchWithTimeout('/getCaptivePortalStatusAsJson', {}, 5000)
        .then(response => {
            if (!response.ok) {
                console.error('Response not OK:', response.status, response.statusText);
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(captivePortalSettings => {
            // if (captivePortalDebug) console.log("Received JSON:", captivePortalSettings);

            // Handle the JSON data
            try {
                handleCaptivePortalData(captivePortalSettings);
            } catch (e) {
                console.error("Error in handleCaptivePortalData:", e);
                throw e; // Re-throw the error to be caught in the catch block
            }
        })
        .catch(error => {
            console.error("Error fetching captive portal status:", error);
            // showServerStatusDot(true, "status-dot-red", "Connection to server lost");
        });
}

/**
 * Sets up the initial settings based on URL parameters.
 */
function setupInitialSettings() {
    if (window.location.href.includes("forcedCaptivePortal")) {
        if (captivePortalDebug) console.log('Forcing captive portal to be active in test mode by forcedCaptivePortal parameter in URL');
        forcedCaptivePortal = true;
        captivePortalActive = true;
    }

    if (window.location.href.includes("debugCaptivePortal")) {
        forcedCaptivePortalDebug = true;
        captivePortalDebug = true;
        console.log('Forcing captive portal debug mode to be active by debugCaptivePortal parameter in URL');
    }

    setCaptivePortalSettings(60, true);
}

/**
 * Initialize the captive portal for preferences.html.
 */
function initializeCaptivePortal() {
    if (captivePortalDebug) console.log('Document loaded. Initializing captive portal for preferences.html');

    getFeaturesAsJson(); // Fetch features from the server
    if (features.SUPPORT_OTA) {
        const otaBadge = document.getElementById('otaBadge');
        if (otaBadge) otaBadge.classList.remove('hidden');
        const maintenanceSection = document.getElementById('maintenanceSection');
        if (maintenanceSection) maintenanceSection.classList.remove('hidden');
    }

    // getCaptivePortalSettings(); // Fetch initial settings
    setupInitialSettings();

    // Poll captive portal status every 5 s — sufficient for UI responsiveness
    // while avoiding hammering the ESP32 web server.
    setInterval(getCaptivePortalSettings, 5000);
}


/**
 * Shows or hides the captivePortalSettings fieldset based on the provided flag.
 * @param {boolean} show - Determines whether to show or hide the captivePortalSettings fieldset.
 */
function showCaptivePortalSettings(show) {
    const captivePortalSettings = document.getElementById('captivePortalSettings');
    if (captivePortalSettings) {
        if (show) {
            captivePortalSettings.classList.remove('hidden');
        } else {
            captivePortalSettings.classList.add('hidden');
        }
    } else {
        console.error('Element with ID "captivePortalSettings" not found.');
    }
}

/**
 * Adjust the padding-top of the content based on the navbar height.
 */
function adjustContentPadding() {
    const navbar = document.querySelector('.navbar');
    const content = document.querySelector('.content');

    if (navbar && content) {
        const navbarHeight = navbar.offsetHeight;
        content.style.paddingTop = `${navbarHeight}px`;
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const currentPage = window.location.pathname.split("/").pop();

    adjustContentPadding();

    if (currentPage === "preferences.html") {
        initializeCaptivePortal();
        highlightCurrentPage(); // Highlight the current page in the navigation bar

        const debugWindow = document.getElementById('debug-window');
        if (captivePortalDebug || debugWindowActive) {
            if (debugWindow) {
                createDebugWindow(debugWindow);
                debugWindowActive = true;
                debugWindow.style.display = 'block';
            } else {
                console.error('Element with ID "debug-window" not found.');
            }
        } else {
            if (debugWindow) {
                debugWindow.style.display = 'none';
                debugWindowActive = false;
            }
        }
    } else {
        if (captivePortalDebug) console.log('Not on preferences.html, skipping debug window initialization');
    }


});
var captivePortalDebug = false;
var forcedCaptivePortalDebug = false;
var debugWindowActive = false;

/**
 * Updates the debug window with the given data.
 * @param {Object} data - The data to display in the debug window.
 */
function updateDebugWindow(data) {
    if (debugWindowActive) {
        const debugContent = document.getElementById('debug-content');
        if (debugContent) {
            // if (captivePortalDebug) console.log('Updating debug window with data:', data);
            let content = `
            <div>captivePortalActive: ${captivePortalActive}</div>
            <div>captivePortalNoTimeout: ${captivePortalNoTimeout}</div>
            <div>timeToWaitForCaptivePortal: ${data.timeToWaitForCaptivePortal}</div>`;

            if (captivePortalActive && !captivePortalNoTimeout) {
                content += `<div>captivePortalTimeLeft: ${captivePortalStatus.captivePortalTimeLeft}</div> `;
            } else {
                if (captivePortalNoTimeout) {
                    content += `<div>Timeout: <strong>Disabled</strong></div>`;
                }
            }

            if (relaxedSecurity) {
                // if (captivePortalDebug) console.log('Adding relaxedSecurity to debug window:', relaxedSecurity);
                content += `<div>relaxedSecurity: ${relaxedSecurity}</div>`;
            }
            if (forcedCaptivePortal) {
                // if (captivePortalDebug) console.log('Adding forcedCaptivePortal to debug window:', forcedCaptivePortal);
                content += `<div>forcedCaptivePortal: ${forcedCaptivePortal}</div>`;
            }
            if (forcedCaptivePortalDebug) {
                // if (captivePortalDebug) console.log('Adding forcedCaptivePortalDebug to debug window:', forcedCaptivePortalDebug);
                content += `<div>forcedCaptivePortalDebug: ${forcedCaptivePortalDebug}</div>`;
            }
            debugContent.innerHTML = content;
            showDebugWindow(true);
        }
    } else {
        showDebugWindow(false);
    }
}

/**
 * Shows or hides the debug window based on the provided flag.
 * @param {boolean} show - Flag indicating whether to show or hide the debug window.
 */
function showDebugWindow(show) {
    const debugWindow = document.getElementById('debug-window');
    if (debugWindow) {
        const isCurrentlyVisible = !debugWindow.classList.contains('hidden-debug-window') && debugWindow.style.display !== 'none';

        if (show && !isCurrentlyVisible) {
            debugWindow.classList.remove('hidden-debug-window');
            debugWindow.style.display = 'block';
            debugWindowActive = true;
            if (captivePortalDebug) console.log('Showing debug window');
        } else if (!show && isCurrentlyVisible) {
            debugWindow.classList.add('hidden-debug-window');
            debugWindow.style.display = 'none';
            debugWindowActive = false;
            if (captivePortalDebug) console.log('Hiding debug window');
        }
    } else {
        console.error('Element with ID "debug-window" not found.');
    }
    showCaptivePortalSettings(show); // Show captive portal settings when debug window is shown (for development)
}

/**
 * Creates a debug window with a close button and debug content.
 */
function createDebugWindow() {
    const debugWindow = document.getElementById('debug-window');
    const closeButton = document.createElement('button');
    closeButton.id = 'close-debug-window';
    closeButton.innerHTML = '[X]';
    closeButton.onclick = () => {
        showDebugWindow(false);
    };
    debugWindow.appendChild(closeButton);

    const debugContent = document.createElement('div');
    debugContent.id = 'debug-content';
    debugWindow.appendChild(debugContent);
}

function initializeDebugWindowUrlParameters() {
    if (window.location.href.includes("forcedDebugWindow")) {
        if (captivePortalDebug) {
            console.log('Forcing debug window to be active by forcedDebugWindow parameter in URL');
            forcedCaptivePortalDebug = true;
            debugWindowActive = true;
        }
    }
}

document.addEventListener("DOMContentLoaded", function () {
    // Get actual page name
    var currentFileName = window.location.pathname.split("/").pop();

    // Verify if the current page is preferences.html
    if (currentFileName === "preferences.html") {
        // Ejecutar el código si el archivo es preferences.html
        initializeDebugWindowUrlParameters();
        createDebugWindow();
        // setInterval(updateStatusBar, 1000);
    }
});

var captivePortalStatusBarActive = false;
var forcedCaptivePortalStatusBar = false;
var captivePortalStatusBarDebug = true;


/**
 * Updates the status bar content and sets up the event listener for the disable timeout checkbox.
 */
function updateStatusBarContent() {
    if (captivePortalActive) {
        // if (captivePortalDebug) console.log('Captive portal active. Showing status bar');
        // updateStatusBar('Captive portal active (test mode)');

        const statusBarContentElement = document.getElementById('status-bar-content');
        // Timeout time: captivePortalStatus.captivePortalTimeLeft
        if (statusBarContentElement) {
            if (!captivePortalNoTimeout) {
                // set id="disableTimeoutCheckbox" to unchecked
                statusBarContentElement.innerHTML = `
                <span>Timeout: <strong>${captivePortalStatus.captivePortalTimeLeft}</strong> seconds</span>
                <label><input type="checkbox" id="disableTimeoutCheckbox"> Disable</label>
            `;
            } else {
                // set id="disableTimeoutCheckbox" to checked
                statusBarContentElement.innerHTML = `
                <span>Timeout: <strong>Disabled</strong></span>
                <label><input type="checkbox" id="disableTimeoutCheckbox" checked> Disable</label>
            `;
            }
        } else {
            console.error('Element with ID "status-bar-content" not found.');
        }

        const disableTimeoutCheckbox = document.getElementById('disableTimeoutCheckbox');
        if (disableTimeoutCheckbox) {
            disableTimeoutCheckbox.checked = captivePortalNoTimeout;
            disableTimeoutCheckbox.addEventListener('change', function () {
                const timeToWait = this.checked ? 0 : 60;
                captivePortalNoTimeout = this.checked;
                console.log('Setting time to wait:', timeToWait);
                console.log('Disabling timeout:', captivePortalNoTimeout);
                setCaptivePortalSettings(timeToWait);
            });
        }

        // if (captivePortalDebug) console.log('Setting initial captive portal settings');
        // setCaptivePortalSettings(60, true);
    } else {
        updateStatusBar('Captive portal inactive');
        showCaptivePortalStatusBar(false);
    }
}

/**
 * Shows or hides the captive portal status bar.
 * @param {boolean} show - Determines whether to show or hide the status bar.
 */
function showCaptivePortalStatusBar(show) {
    if (captivePortalStatusBarActive === show) return;

    const captivePortalStatusBar = document.getElementById('captive-portal-status-bar');
    if (captivePortalStatusBar) {
        if (captivePortalStatusBarDebug) console.log('Captive portal status bar found:', captivePortalStatusBar);

        if (show) {
            if (captivePortalStatusBarDebug) console.log('Showing captive portal status bar');
            captivePortalStatusBar.classList.remove('hidden-captive-portal-status-bar');
        } else {
            if (captivePortalStatusBarDebug) console.log('Hiding captive portal status bar');
            captivePortalStatusBar.classList.add('hidden-captive-portal-status-bar');
        }
        captivePortalStatusBarActive = show;
    } else {
        console.error('Element with ID "captive-portal-status-bar" not found.');
    }
}

/**
 * Initializes the Captive Portal Status Bar.
 */
function initializeCaptivePortalStatusBar() {
    if (captivePortalStatusBarDebug) console.log('Initializing captive portal status bar');

    const captivePortalStatusBar = document.getElementById('captive-portal-status-bar');
    if (captivePortalStatusBar) {
        if (captivePortalStatusBarDebug) console.log('Injecting captive portal status bar content');
        captivePortalStatusBar.innerHTML = `
            <span id="status-bar-content"></span>
            <span id="hide-captive-portal-status-bar-button" onclick="showCaptivePortalStatusBar(false)">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="10" stroke="black" stroke-width="2"/>
                    <line x1="8" y1="8" x2="16" y2="16" stroke="black" stroke-width="2"/>
                    <line x1="16" y1="8" x2="8" y2="16" stroke="black" stroke-width="2"/>
                </svg>
            </span>
        `;
        if (forcedCaptivePortal) showCaptivePortalStatusBar(true);
    } else {
        console.error('Element with ID "captive-portal-status-bar" not found.');
    }
}

function initializeCaptivePortalStatusBarUrlParameters() {
    captivePortalStatusBarDebug = window.location.href.includes("captivePortalStatusBarDebug");
    if (captivePortalStatusBarDebug) console.log('Captive portal status bar debug:', captivePortalStatusBarDebug);
    forcedCaptivePortalStatusBar = window.location.href.includes("forcedCaptivePortalStatusBar");
    if (captivePortalStatusBarDebug) console.log('Captive portal status bar forced:', forcedCaptivePortalStatusBar);
}

/**
 * Updates the content of the status bar.
 * @param {string} content - The content to display in the status bar.
 */
function updateStatusBar(content) {
    if (!captivePortalStatusBarActive) return;
    if (captivePortalStatusBarDebug) console.log('Updating status bar');
    const statusContent = document.getElementById('status-bar-content');
    if (statusContent) {
        statusContent.textContent = content;
        if (captivePortalStatusBarDebug) console.log('Updating status bar content:', content);
    } else {
        console.error('Element with ID "status-bar-content" not found.');
    }
}

document.addEventListener("DOMContentLoaded", function () {
    initializeCaptivePortalStatusBarUrlParameters();
    initializeCaptivePortalStatusBar();
    // setInterval(updateStatusBar, 1000);
    setInterval(updateStatusBarContent, 1000);
});
var canPingServer = true;

let previousServerStatusDotState = {
    show: null,
    colorClass: '',
    title: ''
};

/**
 * Shows or hides the server status dot based on the provided flag.
 * @param {boolean} show - Determines whether to show or hide the server status dot.
 * @param {string} [colorClass] - The color class to apply.
 * @param {string} [title] - The title to apply for hover text.
 */
function displayServerStatusDot(show, colorClass = 'status-dot-cyan', title = '') {
    const serverStatusDot = document.getElementById('server-status-dot');
    if (serverStatusDot) {
        const hasStateChanged =
            previousServerStatusDotState.show !== show ||
            previousServerStatusDotState.colorClass !== colorClass ||
            previousServerStatusDotState.title !== title;

        if (hasStateChanged) {
            serverStatusDot.className = 'status-dot'; // Reset class
            serverStatusDot.classList.add(show ? colorClass : 'status-dot-hidden');
            serverStatusDot.title = title;

            if (captivePortalDebug) {
                console.log(`Server status dot updated: show=${show}, colorClass=${colorClass}, title=${title}`);
            }

            // Update previous state
            previousServerStatusDotState.show = show;
            previousServerStatusDotState.colorClass = colorClass;
            previousServerStatusDotState.title = title;
        }
    } else {
        console.error('Element with ID "server-status-dot" not found.');
    }
}

/**
 * Checks the server connection periodically.
 */
function checkServerConnection() {
    fetchWithTimeout('/pingServer', {}, 3000)
        .then(response => {
            canPingServer = response.ok;
            if (!response.ok) captivePortalActive = false;
        })
        .catch(error => {
            console.error('Error pinging server:', error);
            canPingServer = false;
            captivePortalActive = false;
        });
}

/**
 * Updates the server status dot based on the captive portal status.
 */
function updateServerStatusDot() {
    let show, colorClass, title;

    if (!canPingServer) {
        show = true;
        colorClass = 'status-dot-red';
        title = 'Connection to server lost';
    } else if (!captivePortalActive) {
        show = false;
        colorClass = 'status-dot-hidden';
        title = 'Captive portal inactive';
    } else if (forcedCaptivePortal) {
        show = true;
        colorClass = 'status-dot-blue';
        title = 'Captive portal active (test mode)';
    } else {
        show = true;
        colorClass = 'status-dot-cyan';
        title = 'Captive portal active';
    }

    // Call displayServerStatusDot with the new state
    displayServerStatusDot(show, colorClass, title);

    // if (captivePortalDebug) {
    //     console.log('Updated server status dot based on captive portal status');
    //     console.log('captivePortalActive:', captivePortalActive, 'forcedCaptivePortal:', forcedCaptivePortal);
    // }
}

document.addEventListener("DOMContentLoaded", function () {
    // Poll at 5 s — reduces request rate on ESP32 while still detecting connectivity loss promptly
    setInterval(updateServerStatusDot, 5000);
    setInterval(checkServerConnection, 5000);
});
/**
 * Loads WHO/ASHRAE recommended CO2 quality thresholds into the form fields.
 * Warning: 800 ppm, Danger: 1000 ppm
 */
let supportBTHomeBLE = false;

function loadWHOPreset() {
    const orangeEl = document.getElementById('co2OrangeRange');
    const redEl    = document.getElementById('co2RedRange');
    if (orangeEl) orangeEl.value = 800;
    if (redEl)    redEl.value    = 1000;
    sanityCheckData();
}

/**
 * Fetches version information from the server and updates the version displayed
 */
function displayVersion() {

    fetchVersion()
        .then(versionInfo => {
            let versionText = `CO2 Gadget: v${versionInfo.firmVerMajor}.${versionInfo.firmVerMinor}.${versionInfo.firmRevision}`;
            if (versionInfo.firmBranch) {
                versionText += `-${versionInfo.firmBranch}`;
            }
            versionText += ` (Flavour: ${versionInfo.firmFlavour})`;
            if (versionInfo.firmBuildDate) versionText += ` — Built: ${versionInfo.firmBuildDate}`;
            if (versionInfo.firmBuildTime) versionText += ` at ${versionInfo.firmBuildTime}`;
            document.getElementById("co2GadgetVersion").innerText = versionText;

            // Adjust preferences.html for specific versions
            if (versionInfo.firmFlavour == 'T-Display S3') {
                const displayBrightInput = document.getElementById("DisplayBright");
                displayBrightInput.min = "1";
                displayBrightInput.max = "16";
                displayBrightInput.step = "1";
                const tooltipText = document.querySelector('#displayBrightDiv .tooltip-text');
                let currentText = tooltipText.textContent;
                currentText += ' Valid brightness values: 1-16.';

            } else {
                const displayBrightInput = document.getElementById("DisplayBright");
                let min = displayBrightInput.min;
                let max = displayBrightInput.max;
                const tooltipText = document.querySelector('#displayBrightDiv .tooltip-text');
                let currentText = tooltipText.textContent;
                currentText += ' Valid brightness values: ' + min + ' to ' + max + '.';
                tooltipText.textContent = currentText;
            }

            // TO-DO: Change to use getFeaturesAsJson endpoint to check for "EINK" instead of firmFlavour to reduce complexity
            if (versionInfo.firmFlavour == 'GDEM0213B74' || versionInfo.firmFlavour == 'DEPG0213BN' || versionInfo.firmFlavour == 'GDEW0213M21' || versionInfo.firmFlavour == 'GDEM029T94' || versionInfo.firmFlavour == 'GDEH0154D67-WeAct' || versionInfo.firmFlavour == 'DEPG0213BN-WeAct' || versionInfo.firmFlavour == 'GDEW0213M21-WeAct' || versionInfo.firmFlavour == 'GDEMGxEPD2_290_BS-WeAct') {
                document.getElementById("displayBrightDiv").classList.add("hidden");
                document.getElementById("dispOffOnExPDiv").classList.add("hidden");
                document.getElementById("tToDispOffDiv").classList.add("hidden");
            }
        })
        .catch(error => {
            console.error('Error displaying version:', error);
        });

}

/**
 * Populates the preferences form with the provided preferences data.
 * @param {Object} preferences - The preferences data to populate the form with.
 */
function populateFormWithPreferences(preferences) {
    supportBTHomeBLE = preferences.supportBTHomeBLE === true;

    // Update relaxedSecurity if present in data
    if (preferences.relaxedSecurity !== undefined) {
        if (preferencesDebug) console.log(`Setting relaxedSecurity field to:`, preferences.relaxedSecurity);
        // If forcedRelaxedSecurity is set because the current URL does contains the "relaxedSecurity" parameter, do not overide the value with the one from the server
        if (!forcedRelaxedSecurity) {
            relaxedSecurity = preferences.relaxedSecurity;
        }
    }

    handlePasswordFields();

    // Helper function to set form values
    const setFormValue = (elementId, value) => {
        const element = document.getElementById(elementId);
        if (element) element.value = value;
        if (preferencesDebug) console.log(`Setting ${elementId} to:`, value);
    };

    // Helper function to set form checkbox
    const setFormCheckbox = (elementId, isChecked) => {
        const element = document.getElementById(elementId);
        if (element) element.checked = isChecked;
        if (preferencesDebug) console.log(`Setting ${elementId} to:`, isChecked);
    };

    setFormCheckbox("activeWIFI", preferences.activeWIFI);
    setFormValue("wifiSSID", preferences.wifiSSID);
    if (relaxedSecurity) setFormValue("wifiPass", preferences.wifiPass);
    setFormValue("hostName", preferences.hostName);
    setFormCheckbox("useStaticIP", preferences.useStaticIP);
    setFormValue("staticIP", preferences.staticIP);
    setFormValue("gateway", preferences.gateway);
    setFormValue("subnet", preferences.subnet);
    setFormValue("dns1", preferences.dns1);
    setFormValue("dns2", preferences.dns2);
    setFormValue("selCO2Sensor", preferences.selCO2Sensor);
    setFormCheckbox("autoSelfCalibration", preferences.autoSelfCal);
    setFormValue("customCalValue", preferences.customCalValue);
    setFormValue("co2OrangeRange", preferences.co2OrangeRange);
    setFormValue("co2RedRange", preferences.co2RedRange);
    setFormValue("tempOffset", preferences.tempOffset);
    setFormCheckbox("showFahrenheit", preferences.showFahrenheit);
    setFormValue("altitudeMeters", preferences.altitudeMeters);
    setFormValue("measurementInterval", preferences.measurementInterval);
    setFormCheckbox("outModeRelay", preferences.outModeRelay);
    setFormValue("channelESPNow", preferences.channelESPNow);
    setFormValue("boardIdESPNow", preferences.boardIdESPNow);
    setFormValue("peerESPNowAddress", preferences.peerESPNowAddress);
    setFormValue("neopixBright", preferences.neopixBright);
    setFormValue("selNeopxType", preferences.selNeopxType);
    setFormCheckbox("activeBLE", preferences.activeBLE);
    if (isBTHomeSupported()) {
        setFormCheckbox("activeBTHome", preferences.activeBTHome);
        setFormCheckbox("bthomeEncryption", preferences.bthomeEncryption);
        if (relaxedSecurity) setFormValue("bthomeBindKey", preferences.bthomeBindKey);
    }
    setFormCheckbox("activeMQTT", preferences.activeMQTT);
    setFormCheckbox("activeESPNOW", preferences.activeESPNOW);
    setFormValue("mqttClientId", preferences.mqttClientId);
    setFormCheckbox("mqttShowInCon", preferences.mqttShowInCon);
    setFormValue("rootTopic", preferences.rootTopic);
    setFormValue("mqttBroker", preferences.mqttBroker);
    setFormValue("mqttUser", preferences.mqttUser);
    if (relaxedSecurity) setFormValue("mqttPass", preferences.mqttPass);
    setFormCheckbox("hasBattery", preferences.hasBattery);
    setFormValue("batDischgd", preferences.batDischgd);
    setFormValue("batChargd", preferences.batChargd);
    setFormValue("vRef", preferences.vRef);
    setFormValue("tToDispOff", preferences.tToDispOff);
    setFormValue("tToPubMQTT", preferences.tToPubMQTT);
    setFormValue("tToPubESPNow", preferences.tToPubESPNow);
    setFormValue("tKeepAlMQTT", preferences.tKeepAlMQTT);
    setFormValue("tKeepAlESPNow", preferences.tKeepAlESPNow);
    setFormCheckbox("showTemp", preferences.showTemp);
    setFormCheckbox("showHumidity", preferences.showHumidity);
    setFormCheckbox("showBattery", preferences.showBattery);
    setFormCheckbox("showStatusIcons", preferences.showStatusIcons);
    setFormCheckbox("wakeOnCO2Alert", preferences.wakeOnCO2Alert);
    setFormCheckbox("showCO2", preferences.showCO2);
    setFormCheckbox("dispOffOnExP", preferences.dispOffOnExP);
    setFormCheckbox("displayReverse", preferences.displayReverse);
    setFormValue("DisplayBright", preferences.DisplayBright);
    setFormCheckbox("debugSensors", preferences.debugSensors);
    setFormValue("toneBzrBeep", preferences.toneBzrBeep);
    setFormValue("durBzrBeep", preferences.durBzrBeep);
    setFormValue("timeBtwnBzr", preferences.timeBtwnBzr);

    // New fields for Captive Portal
    if (preferences.cpNoTimeout !== undefined) {
        setFormCheckbox("cpNoTimeout", preferences.cpNoTimeout);
    }
    if (preferences.cpRelaxedSec !== undefined) {
        setFormCheckbox("cpRelaxedSec", preferences.cpRelaxedSec);
    }
    if (preferences.cpDebug !== undefined) {
        setFormCheckbox("cpDebug", preferences.cpDebug);
    }
    if (preferences.cpWaitTime !== undefined) {
        setFormValue("cpWaitTime", preferences.cpWaitTime);
    }

    toggleVisibility('activeWIFI', 'wifiNetworks', (isChecked) => {
        document.getElementById('mqttConfig').style.display = isChecked ? 'block' : 'none';
    });
    toggleVisibility('activeMQTT', 'mqttConfig');
    toggleVisibility('activeESPNOW', 'espNowConfig');
    toggleVisibility('useStaticIP', 'staticIPSettings');

    // Handle dependencies after form is populated
    handleWiFiMQTTDependency();
    applyFeatureVisibility();
}

/**
 * Fetches preferences data from the server and populates the form.
 */
function loadPreferencesFromServer() {
    fetch('/getActualSettingsAsJson' + (relaxedSecurity ? '?relaxedSecurity=true' : ''))
        .then(response => response.json())
        .then(preferences => {
            if (preferencesDebug) console.log('Get preferences from server response:', preferences);
            populateFormWithPreferences(preferences);
        })
        .catch(error => console.error('Error retrieving preferences:', error));
}

/**
 * Collects preferences data from the form.
 * @returns {Object} - The collected preferences data.
 */
function setBTHomeSupportVisibility(isSupported) {
    ["activeBTHome", "bthomeEncryption", "bthomeBindKey"].forEach((id) => {
        const element = document.getElementById(id);
        const formGroup = element ? element.closest(".form-group") : null;
        if (formGroup) formGroup.classList.toggle("hidden", !isSupported);
    });
    updateBTHomeControlsState();
}

function isBTHomeSupported() {
    return features.SUPPORT_BTHOME_BLE || supportBTHomeBLE;
}

function updateBTHomeControlsState() {
    const bthomeCheckbox = document.getElementById("activeBTHome");
    const encryptionCheckbox = document.getElementById("bthomeEncryption");
    const bindKeyInput = document.getElementById("bthomeBindKey");
    const bthomeSupported = isBTHomeSupported();
    const bthomeActive = bthomeSupported && !!(bthomeCheckbox && bthomeCheckbox.checked);

    if (bthomeCheckbox) bthomeCheckbox.disabled = !bthomeSupported;
    if (encryptionCheckbox) encryptionCheckbox.disabled = !bthomeActive;
    if (bindKeyInput) bindKeyInput.disabled = !bthomeActive || !relaxedSecurity;
}

function setFormGroupVisibility(elementId, isVisible) {
    const element = document.getElementById(elementId);
    const formGroup = element ? element.closest(".form-group") : null;
    if (formGroup) formGroup.classList.toggle("hidden", !isVisible);
    if (element && !isVisible && element.type === 'checkbox') {
        element.disabled = true;
    } else if (element) {
        element.disabled = false;
    }
}

function setSectionVisibility(elementId, isVisible) {
    const element = document.getElementById(elementId);
    if (element) element.classList.toggle("hidden", !isVisible);
}

function applyFeatureVisibility() {
    const activeMQTT = document.getElementById("activeMQTT");
    const activeESPNOW = document.getElementById("activeESPNOW");

    setFormGroupVisibility("activeBLE", features.SUPPORT_BLE);
    setBTHomeSupportVisibility(isBTHomeSupported());
    setFormGroupVisibility("activeMQTT", features.SUPPORT_MQTT);
    setFormGroupVisibility("activeESPNOW", features.SUPPORT_ESPNOW);
    setFormGroupVisibility("mqttShowInCon", features.SUPPORT_MQTT);
    setSectionVisibility("mqttConfig", features.SUPPORT_MQTT && !!(activeMQTT && activeMQTT.checked));
    setSectionVisibility("espNowConfig", features.SUPPORT_ESPNOW && !!(activeESPNOW && activeESPNOW.checked));
    setSectionVisibility("lowPowerSection", features.SUPPORT_LOW_POWER);
}

function normalizeBTHomeBindKey(value) {
    return String(value || '').trim().replace(/[\s:-]/g, '').toLowerCase();
}

function validateBTHomeBindKey(value) {
    if (!value) return '';
    const trimmedValue = String(value).trim();
    if (trimmedValue === '-') return trimmedValue;

    const normalizedValue = normalizeBTHomeBindKey(trimmedValue);
    if (!/^[0-9a-f]{32}$/.test(normalizedValue)) {
        throw new Error('BTHome bind key must be exactly 32 hexadecimal characters.');
    }

    return normalizedValue;
}

function collectPreferencesData() {
    try {
        const preferencesData = {};

        const setValue = (id, type = 'value') => {
            const element = document.getElementById(id);
            if (element) {
                preferencesData[id] = (type === 'checked') ? element.checked : element.value;
                return true; // Successfully set value
            } else {
                console.warn(`Element with ID '${id}' not found.`);
                return false; // Element not found
            }
        };

        // Setting values for preferencesData
        setValue("customCalValue");
        setValue("tempOffset");
        setValue("altitudeMeters");
        setValue("autoSelfCalibration", 'checked');
        setValue("co2OrangeRange");
        setValue("co2RedRange");
        setValue("DisplayBright");
        setValue("neopixBright");
        setValue("selNeopxType");
        if (features.SUPPORT_BLE) setValue("activeBLE", 'checked');
        if (isBTHomeSupported()) {
            setValue("activeBTHome", 'checked');
            setValue("bthomeEncryption", 'checked');
            setValue("bthomeBindKey");
            preferencesData.bthomeBindKey = validateBTHomeBindKey(preferencesData.bthomeBindKey);
        }
        if (features.SUPPORT_BLE || isBTHomeSupported()) {
            preferencesData.enableBLE = !!(preferencesData.activeBLE || preferencesData.activeBTHome);
        }
        setValue("activeWIFI", 'checked');
        if (features.SUPPORT_MQTT) setValue("activeMQTT", 'checked');
        if (features.SUPPORT_ESPNOW) setValue("activeESPNOW", 'checked');
        if (features.SUPPORT_MQTT) setValue("rootTopic");
        setValue("hasBattery", 'checked');
        setValue("batDischgd");
        setValue("batChargd");
        setValue("vRef");
        setValue("tToDispOff");
        if (features.SUPPORT_MQTT) setValue("tToPubMQTT");
        if (features.SUPPORT_ESPNOW) setValue("tToPubESPNow");
        if (features.SUPPORT_MQTT) setValue("tKeepAlMQTT");
        if (features.SUPPORT_ESPNOW) setValue("tKeepAlESPNow");
        setValue("dispOffOnExP", 'checked');
        setValue("wifiSSID");
        setValue("hostName");
        setValue("useStaticIP", 'checked');
        setValue("staticIP");
        setValue("gateway");
        setValue("subnet");
        setValue("dns1");
        setValue("dns2");
        setValue("selCO2Sensor");
        setValue("debugSensors", 'checked');
        setValue("displayReverse", 'checked');
        setValue("showFahrenheit", 'checked');
        setValue("measurementInterval");
        setValue("outModeRelay", 'checked');
        setValue("channelESPNow");
        setValue("boardIdESPNow");
        setValue("peerESPNowAddress");
        setValue("showTemp", 'checked');
        setValue("showHumidity", 'checked');
        setValue("showBattery", 'checked');
        setValue("showStatusIcons", 'checked');
        setValue("wakeOnCO2Alert", 'checked');
        setValue("showCO2", 'checked');
        if (features.SUPPORT_MQTT) {
            setValue("mqttClientId");
            if (features.SUPPORT_MQTT) setValue("mqttShowInCon", 'checked');
            setValue("mqttBroker");
            setValue("mqttUser");
        }
        setValue("toneBzrBeep");
        setValue("durBzrBeep");
        setValue("timeBtwnBzr");

        if (relaxedSecurity) {
            setValue("wifiPass");
            if (features.SUPPORT_MQTT) setValue("mqttPass");
        }

        // New fields for Captive Portal
        setValue("cpNoTimeout", 'checked');
        setValue("cpRelaxedSec", 'checked');
        setValue("cpDebug", 'checked');
        setValue("cpWaitTime");

        console.log("Collected preferences data:", preferencesData);

        return preferencesData;
    } catch (error) {
        console.error("Error collecting preferences data:", error);
        alert(error.message || "An error occurred while collecting preferences data. Please check the console for details.");
        throw error; // Re-throw the error after logging it
    }
}

/**
 * Shows a popup message indicating that preferences are being saved.
 */
function showSavingPopup() {
    const popup = document.getElementById("popup");
    popup.style.display = "block";
    console.log("Show popup");

    setTimeout(() => {
        popup.style.display = "none";
        console.log("Hide popup");
    }, 2000);
}

/**
 * Saves preferences to the server.
 */
function savePreferences() {
    const preferencesData = collectPreferencesData();
    showSavingPopup();
    if (preferencesDebug) console.log("Sending preferences to server:", preferencesData);

    fetch('/savePreferences', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(preferencesData)
    })
        .then(response => {
            if (response.ok) {
                console.log("Preferences updated successfully!");
            } else {
                alert("Error updating preferences. Please try again.");
            }
        })
        .catch(error => console.error('Error saving preferences:', error));
}

/**
 * Backs up preferences by saving them to a JSON file.
 */
function backupPreferences() {
    const preferencesData = collectPreferencesData();
    const jsonData = JSON.stringify(preferencesData);
    const blob = new Blob([jsonData], { type: 'application/json' });
    const a = document.createElement('a');

    a.href = URL.createObjectURL(blob);
    a.download = 'preferences_backup.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    alert('Preferences backup completed successfully!');
}

/**
 * Restores preferences from the provided JSON data.
 * @param {string} preferencesData - The JSON string containing preferences data.
 */
function restorePreferencesFromData(preferencesData) {
    const preferences = JSON.parse(preferencesData);
    populateFormWithPreferences(preferences);
}

/**
 * Triggers file input click event to restore preferences from a file.
 */
function chooseFileAndRestore() {
    document.getElementById('fileInput').click();
}

/**
 * Handles file selection for restoring preferences.
 * @param {Event} event - The file selection event.
 */
function handleFileSelection(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.readAsText(file, 'UTF-8');
        reader.onload = (evt) => {
            const preferencesData = evt.target.result;
            restorePreferencesFromData(preferencesData);
        };
        reader.onerror = (evt) => {
            console.error("Error reading file:", evt.target.error);
            alert("Error reading file. Please try again.");
        };
    }
}

/**
 * Toggles the visibility of an element based on a checkbox state and handles subdependencies.
 * @param {string} checkboxId - The ID of the checkbox.
 * @param {string} elementId - The ID of the element to toggle.
 * @param {function} [callback] - Optional callback function to handle additional dependencies.
 */
function toggleVisibility(checkboxId, elementId, callback) {
    const checkbox = document.getElementById(checkboxId);
    const element = document.getElementById(elementId);

    if (!checkbox || !element) {
        console.error(`Checkbox or element not found: ${checkboxId}, ${elementId}`);
        return;
    }

    const toggleElement = () => {
        element.style.display = checkbox.checked ? 'block' : 'none';
        if (callback) callback(checkbox.checked);
    };

    toggleElement();
    checkbox.addEventListener('change', toggleElement);
}

/**
 * Ensures that MQTT is disabled when WiFi is disabled, and enabled when WiFi is enabled.
 */
function handleWiFiMQTTDependency() {
    const wifiCheckbox = document.getElementById('activeWIFI');
    const mqttCheckbox = document.getElementById('activeMQTT');

    if (!wifiCheckbox || !mqttCheckbox) {
        console.error('Checkboxes not found: activeWIFI, activeMQTT');
        return;
    }

    const updateMQTTState = () => {
        if (!features.SUPPORT_MQTT || !wifiCheckbox.checked) {
            mqttCheckbox.checked = false;
            mqttCheckbox.disabled = true;
            document.getElementById('mqttConfig').style.display = 'none';
        } else {
            mqttCheckbox.disabled = false;
        }
    };

    const updateWiFiState = () => {
        if (mqttCheckbox.checked) {
            wifiCheckbox.checked = true;
        }
        toggleVisibility('activeMQTT', 'mqttConfig');
        applyFeatureVisibility();
    };

    wifiCheckbox.addEventListener('change', updateMQTTState);
    mqttCheckbox.addEventListener('change', updateWiFiState);

    // Initial call to set the correct state on page load
    updateMQTTState();
    updateWiFiState();
}

/**
 * Updates the battery voltage displayed on the page.
 */
function updateBatteryVoltage(voltage) {
    document.getElementById('currentVoltage').textContent = voltage + ' Volts';
}

function fetchAndUpdateBatteryVoltage() {
    readBatteryVoltage()
        .then(voltage => {
            updateBatteryVoltage(voltage);
        })
        .catch(error => {
            console.error('Error updating battery voltage:', error);
        });
}

/**
 * Updates the VRef value on the server.
 */
function updateVRef() {
    const vRefValue = document.getElementById('vRef').value;
    fetch(`/settings?SetVRef=${vRefValue}`)
        .then(response => {
            if (!response.ok) throw new Error('Error updating VRef');
            console.log('VRef updated successfully');
        })
        .catch(error => console.error('Error updating VRef:', error));
}

/**
 * Enables or disables password fields based on the relaxed security mode.
 */
function handlePasswordFields() {
    const inputField = document.getElementById("wifiSSID");
    const passwordFields = document.querySelectorAll('input[type=password]');

    passwordFields.forEach(field => {
        if (relaxedSecurity) {
            field.removeAttribute('disabled');
            if (preferencesDebug) console.log(`Field ${field.id} enabled`);
        } else {
            field.disabled = true;
            field.value = '';
            field.placeholder = "Password (disabled)";
            if (preferencesDebug) console.log(`Field ${field.id} disabled`);
        }
    });

    if (relaxedSecurity) {
        inputField.removeAttribute('readonly');
    } else {
        inputField.setAttribute('readonly', 'readonly');
    }
}

function calibrateSensor(calibrationValue) {
    // Implement the calibration logic here
    if (calibrationValue > 400 && calibrationValue < 2000) {
        console.log("Calibration process started...");
        console.log("Calibration value:", calibrationValue);
        fetch(`/settings?CalibrateCO2=${calibrationValue}`)
            .then(response => {
                if (!response.ok) throw new Error('Error calibrating CO2 sensor');
                console.log('CO2 sensor calibrated successfully');
            })
            .catch(error => console.error('Error calibrating CO2 sensor:', error));
    } else {
        console.error(
            "Invalid calibration value, please enter a value between 400 and 2000 ppm"
        );
        console.log("Calibration value:", calibrationValue);
    }
}

/**
 * Handles the calibration wizard functionality.
 */
function handleCalibrationWizard() {
    const calibrateButton = document.getElementById("calibrateButton");
    const calibrationModal = document.getElementById("calibrationModal");
    const countdownModal = document.getElementById("countdownModal");
    const closeSpan = document.querySelector(".close");
    const acknowledgeCheckbox = document.getElementById("acknowledgeCheckbox");
    const acknowledgeLabel = document.getElementById("acknowledgeLabel");
    const calibrateNowButton = document.getElementById("calibrateNowButton");
    const countdownSpan = document.getElementById("countdown");
    const currentCO2ValueSpan = document.getElementById("currentCO2Value");

    // Declared explicitly to avoid implicit global
    let updateCO2Interval = null;

    // Function to fetch current CO2 value from /readCO2 endpoint as text
    function getCurrentCO2Value() {
        fetchWithTimeout('/readCO2', {}, 5000)
            .then((response) => response.text())
            .then((data) => {
                let co2Value = parseFloat(data);
                document.getElementById("currentCO2Value").textContent =
                    co2Value.toFixed(0);
            })
            .catch((error) => {
                console.error("Error fetching CO2 data", error);
            });
    }

    // Function to change text color when "Calibrate Now" button is clicked without acknowledging
    function changeTextColor() {
        acknowledgeLabel.style.color = "var(--unchecked-font-color)";
    }

    calibrateButton.addEventListener("click", () => {
        // Uncheck the acknowledge checkbox when modal is opened
        acknowledgeCheckbox.checked = false;
        calibrationModal.style.display = "block";
        // Set the custom calibration value input to the current custom calibration value
        const customCalibrationValueInput = document.getElementById(
            "modalCustomCalibrationValueInput"
        );
        customCalibrationValueInput.value =
            document.getElementById("customCalValue").value;
        // Fetch current CO2 value when modal is opened
        getCurrentCO2Value();
        // Start interval to update CO2 value every 5 seconds
        updateCO2Interval = setInterval(getCurrentCO2Value, 5000);
    });

    closeSpan.addEventListener("click", () => {
        calibrationModal.style.display = "none";
        // Clear interval when modal is closed
        clearInterval(updateCO2Interval);
    });

    acknowledgeCheckbox.addEventListener("change", () => {
        // Reset text color when checkbox is checked
        if (acknowledgeCheckbox.checked) {
            acknowledgeLabel.style.color = ""; // Reset to default color
        }
    });

    calibrateNowButton.addEventListener("click", () => {
        if (!acknowledgeCheckbox.checked) {
            changeTextColor(); // Call the function to change text color
            return; // Exit function if checkbox is not acknowledged
        }

        calibrationModal.style.display = "none";
        countdownModal.style.display = "block";

        const customCalValue = parseInt(
            document.getElementById("modalCustomCalibrationValueInput").value,
            10
        );
        calibrateSensor(customCalValue);

        let countdown = 15;
        countdownSpan.textContent = countdown;

        const interval = setInterval(() => {
            countdown -= 1;
            countdownSpan.textContent = countdown;

            if (countdown <= 0) {
                clearInterval(interval);
                countdownModal.style.display = "none";
            }
        }, 1000);
    });

    window.addEventListener("click", (event) => {
        if (event.target == calibrationModal) {
            calibrationModal.style.display = "none";
            // Clear interval when modal is closed
            clearInterval(updateCO2Interval);
        }
    });
}

/**
 * Sanity Data form before Save 
 */
function sanityCheckData() {
    var txt_error = "";
    let errorMessage = document.getElementById('error-message');

    // Sanyty check for display brightness
    const inputDisplayBrightness = document.getElementById("DisplayBright");
    if (parseInt(inputDisplayBrightness.value) > parseInt(inputDisplayBrightness.max) || parseInt(inputDisplayBrightness.value) < parseInt(inputDisplayBrightness.min)) {
        inputDisplayBrightness.classList.remove('valid');
        inputDisplayBrightness.classList.add('error');

        if (parseInt(inputDisplayBrightness.value) > parseInt(inputDisplayBrightness.max)) inputDisplayBrightness.value = inputDisplayBrightness.max;
        if (parseInt(inputDisplayBrightness.value) < parseInt(inputDisplayBrightness.min)) inputDisplayBrightness.value = inputDisplayBrightness.min;

        txt_error = "Display Brightness value must be >=" + inputDisplayBrightness.min + " and <=" + inputDisplayBrightness.max;
        if (errorMessage) errorMessage.remove(); // Remove previous error messages
        errorMessage = document.createElement('div');
        errorMessage.id = 'error-message';
        errorMessage.className = 'form-error';
        errorMessage.textContent = txt_error;
        inputDisplayBrightness.insertAdjacentElement('afterend', errorMessage);
        if (preferencesDebug) console.log(txt_error);
        return false;
    } else {
        if (errorMessage) errorMessage.remove();
        inputDisplayBrightness.classList.remove('error');
        inputDisplayBrightness.classList.add('valid');
    }

    // Sanyty check for CO2 Orange and Red Range
    const inputco2OrangeRange = document.getElementById("co2OrangeRange");
    const inputco2RedRange = document.getElementById("co2RedRange");
    if (parseInt(inputco2OrangeRange.value) > parseInt(inputco2RedRange.value)) {
        inputco2RedRange.value = parseInt(inputco2OrangeRange.value) + 1;
        inputco2OrangeRange.classList.remove('valid');
        inputco2RedRange.classList.remove('valid');
        inputco2OrangeRange.classList.add('error');
        inputco2RedRange.classList.add('error');
        txt_error = "Red level must be greater than Orange level";
        if (errorMessage) errorMessage.remove(); // Remove previous error messages
        errorMessage = document.createElement('div');
        errorMessage.id = 'error-message';
        errorMessage.className = 'form-error';
        errorMessage.textContent = txt_error;
        inputco2RedRange.insertAdjacentElement('afterend', errorMessage);
        if (preferencesDebug) console.log(txt_error);
        return false;
    } else {
        if (errorMessage) errorMessage.remove();
        inputco2OrangeRange.classList.remove('error');
        inputco2RedRange.classList.remove('error');
        inputco2OrangeRange.classList.add('valid');
        inputco2RedRange.classList.add('valid');
    }
    return true;
}

/**
 * Runtime display reverse 
 */
function toggleDisplayReverse() {
    if (preferencesDebug) console.log("Toggle Display Reverse");
    fetch("/settings?ToggleDisplayReverse")
        .then(response => {
            if (!response.ok) throw new Error('Error reversing display');
            if (preferencesDebug) console.log('Toggle Display Reverse successfully');
        })
        .catch(error => console.error('Error Toggling Display Reverse:', error));
}

/**
 * Runtime display brightness 
 */
function setDisplayBrightness() {
    const inputDisplayBrightness = document.getElementById("DisplayBright").value;
    if (preferencesDebug) console.log("Set Display Brightness = " + inputDisplayBrightness);
    fetch(`/settings?setDisplayBrightness=${inputDisplayBrightness}`)
        .then(response => {
            if (!response.ok) throw new Error('Error setting display brightness');
            if (preferencesDebug) console.log('Set Display brightness successfully');
        })
        .catch(error => console.error('Error Setting Display brightness:', error));
}

/**
* Runtime show/hide Temp/Humidity/Battery in display
*/
function showTempHumBatt() {
    const inputShowTemp = document.getElementById("showTemp").checked;
    const inputShowHumidity = document.getElementById("showHumidity").checked;
    const inputShowBattery = document.getElementById("showBattery").checked;
    if (preferencesDebug) console.log("Show/hide Temp/Humidity/Battery in display");
    fetch(`/settings?showTemp=${inputShowTemp}&showHumidity=${inputShowHumidity}&showBattery=${inputShowBattery}`)
        .then(response => {
            if (!response.ok) throw new Error('Error setting show/hide Temp/Humidity/Battery in display');
            if (preferencesDebug) console.log('Set show/hide Temp/Humidity/Battery in display successfully');
        })
        .catch(error => console.error('Error show/hide Temp/Humidity/Battery in display', error));
}

/**
 * Reads preferences with retries to tolerate transient network timeouts.
 * Uses exponential backoff: 1 s, 2 s, 4 s between attempts.
 * @param {number} retries - Number of retry attempts after the first failure.
 * @returns {Promise<Object>} Preferences object.
 */
function readPreferencesWithRetry(retries = 3) {
    return readPreferencesFromServer().catch(error => {
        if (retries <= 0) throw error;
        const delay = 1000 * Math.pow(2, 3 - retries); // 1 s, 2 s, 4 s
        console.warn(`Preferences fetch failed, retrying in ${delay}ms… (${retries} left)`);
        return new Promise(resolve => setTimeout(resolve, delay))
            .then(() => readPreferencesWithRetry(retries - 1));
    });
}

document.addEventListener("DOMContentLoaded", () => {
    // Get the current URL
    var currentURL = window.location.href;

    // Check if the current URL contains "preferences.html"
    if (currentURL.includes("preferences.html")) {
        highlightCurrentPage(); // Highlight the current page in the navigation bar
        forcedRelaxedSecurity = currentURL.includes("relaxedSecurity");
        relaxedSecurity = forcedRelaxedSecurity;
        forceCaptivePortalActive = currentURL.includes("forceCaptivePortalActive");
        handlePasswordFields();

        // Show a loading banner while preferences are being fetched
        const form = document.getElementById("preferencesForm");
        const loadingBanner = document.createElement("div");
        loadingBanner.id = "prefsLoadingBanner";
        loadingBanner.style.cssText = "padding:10px 16px;margin-bottom:12px;border-radius:6px;background:var(--input-bg,#f0f0f0);color:var(--font-color,#333);font-size:.9rem;";
        loadingBanner.textContent = "Loading preferences…";
        if (form) form.insertAdjacentElement("beforebegin", loadingBanner);

        function attemptLoad() {
            loadingBanner.textContent = "Loading preferences…";
            // Remove any previous retry button
            const old = document.getElementById("prefsRetryBtn");
            if (old) old.remove();

            readPreferencesWithRetry(3)
                .then(preferences => {
                    populateFormWithPreferences(preferences);
                    displayVersion();
                    loadingBanner.remove();
                })
                .catch(error => {
                    console.error('Error initializing preferences page:', error);
                    loadingBanner.style.background = "var(--red-color,#c0392b)";
                    loadingBanner.style.color = "#fff";
                    loadingBanner.textContent = "Could not load preferences. ";
                    const retryBtn = document.createElement("button");
                    retryBtn.id = "prefsRetryBtn";
                    retryBtn.type = "button";
                    retryBtn.textContent = "Retry";
                    retryBtn.style.cssText = "margin-left:8px;padding:3px 10px;cursor:pointer;border:none;border-radius:4px;background:#fff;color:#c0392b;font-weight:bold;";
                    retryBtn.addEventListener("click", attemptLoad);
                    loadingBanner.appendChild(retryBtn);
                });
        }

        toggleVisibility('activeWIFI', 'wifiNetworks', (isChecked) => {
            document.getElementById('mqttConfig').style.display = isChecked ? 'block' : 'none';
            applyFeatureVisibility();
        });
        toggleVisibility('activeMQTT', 'mqttConfig');
        toggleVisibility('activeESPNOW', 'espNowConfig');
        toggleVisibility('useStaticIP', 'staticIPSettings');
        const bthomeCheckbox = document.getElementById("activeBTHome");
        if (bthomeCheckbox) bthomeCheckbox.addEventListener("change", updateBTHomeControlsState);
        handleWiFiMQTTDependency();
        getFeaturesAsJson()
            .then(() => {
                applyFeatureVisibility();
                attemptLoad();
            });
        handleCalibrationWizard();

        // Update the battery voltage every 5 seconds (voltage changes slowly)
        setInterval(fetchAndUpdateBatteryVoltage, 5000);

        // Listen for input events on the voltage reference field with a proper debounce
        let _vRefDebounceId = null;
        document.getElementById('vRef').addEventListener('input', () => {
            clearTimeout(_vRefDebounceId);
            _vRefDebounceId = setTimeout(updateVRef, 400);
        });

        // Timezone selector — init and live preview
        initTzSelector();
    }
});

/** Initialise the timezone select widget and start the live clock preview. */
function initTzSelector() {
    const sel = document.getElementById('tzOffset');
    const preview = document.getElementById('tzPreview');
    const previewOffset = document.getElementById('tzPreviewOffset');
    if (!sel) return;

    // Select the stored offset (or browser default)
    const stored = localStorage.getItem('co2gadget_tz');
    const current = stored !== null ? parseFloat(stored) : getTzOffsetHours();
    // Find closest option value
    let bestOpt = sel.options[0];
    let bestDiff = Infinity;
    for (const opt of sel.options) {
        const diff = Math.abs(parseFloat(opt.value) - current);
        if (diff < bestDiff) { bestDiff = diff; bestOpt = opt; }
    }
    sel.value = bestOpt.value;
    if (stored === null) saveTzOffset(bestOpt.value); // persist browser default

    function tick() {
        if (!preview) return;
        preview.textContent = formatTimeInTz(Date.now());
        const offset = getTzOffsetHours();
        if (previewOffset) previewOffset.textContent = tzOffsetLabel(offset);
    }
    tick();
    setInterval(tick, 1000);
}
